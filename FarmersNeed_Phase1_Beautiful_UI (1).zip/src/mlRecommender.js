/**
 * ML-based Crop Recommendation Engine
 *
 * Algorithm: Weighted Gaussian Scoring (equivalent to Naive Bayes with Gaussian
 * likelihood). For each crop, each input feature is scored using a bell curve
 * centered on the crop's known optimal value. The overall confidence is the
 * weighted mean of all feature scores, expressed as a percentage.
 *
 * Feature data sourced from:
 *  - Kaggle "Crop Recommendation Dataset" (22 crops, 2200 samples)
 *  - ICAR / AP Agriculture Department advisory tables
 *  - Field extension manuals for Andhra Pradesh / Telangana
 */

'use strict';

// ─── Crop Knowledge Base ─────────────────────────────────────────────────────
// Each crop entry:
//   nameEn   – English name used as key
//   nameTe   – Telugu name shown in the UI
//   mean     – optimal centroid for each feature (from dataset averages)
//   sigma    – acceptable spread (larger = more tolerant of variation)
//   seasons  – which seasons this crop suits
//   soils    – soil types that work well
//   irrigation – compatible irrigation methods
//   notes    – short Telugu farming note shown with the recommendation

const CROP_DB = [
  {
    nameEn: 'paddy',
    nameTe: 'వరి (Paddy)',
    mean:   { N: 80,  P: 47, K: 39, pH: 6.4, temp: 24, humid: 82, rain: 200 },
    sigma:  { N: 30,  P: 20, K: 20, pH: 0.8, temp: 4,  humid: 10, rain: 70 },
    seasons: ['kharif', 'rabi'],
    soils: ['clay', 'loam', 'alluvial', 'black'],
    irrigation: ['canal', 'borewell', 'tank'],
    notes: 'వరి తడి నేలకు అనుకూలం. పూత దశలో నీరు తప్పనిసరి.'
  },
  {
    nameEn: 'maize',
    nameTe: 'మొక్కజొన్న (Maize)',
    mean:   { N: 78,  P: 48, K: 19, pH: 6.3, temp: 22, humid: 66, rain: 65 },
    sigma:  { N: 30,  P: 25, K: 15, pH: 0.9, temp: 5,  humid: 12, rain: 30 },
    seasons: ['kharif', 'rabi'],
    soils: ['loam', 'sandy loam', 'red', 'black'],
    irrigation: ['borewell', 'canal', 'rainfed'],
    notes: 'మొక్కజొన్న పౌల్ట్రీ, పశుగ్రాస మార్కెట్లో ఎక్కువ డిమాండ్ కలిగి ఉంటుంది.'
  },
  {
    nameEn: 'cotton',
    nameTe: 'పత్తి (Cotton)',
    mean:   { N: 118, P: 46, K: 19, pH: 6.9, temp: 25, humid: 60, rain: 80 },
    sigma:  { N: 35,  P: 20, K: 15, pH: 0.9, temp: 5,  humid: 15, rain: 35 },
    seasons: ['kharif'],
    soils: ['black', 'clay', 'loam'],
    irrigation: ['borewell', 'rainfed', 'drip'],
    notes: 'నల్ల నేలలో పత్తి చాలా బాగా పెరుగుతుంది. BT పత్తి రకాలు వాడండి.'
  },
  {
    nameEn: 'groundnut',
    nameTe: 'వేరుశనగ (Groundnut)',
    mean:   { N: 25,  P: 50, K: 40, pH: 6.0, temp: 27, humid: 55, rain: 60 },
    sigma:  { N: 15,  P: 20, K: 20, pH: 0.8, temp: 4,  humid: 12, rain: 25 },
    seasons: ['kharif', 'rabi'],
    soils: ['sandy loam', 'red', 'loam'],
    irrigation: ['borewell', 'rainfed'],
    notes: 'ఎర్ర నేలల్లో వేరుశనగ చాలా అనుకూలం. నూనె పరిశ్రమలకు మంచి డిమాండ్.'
  },
  {
    nameEn: 'red gram',
    nameTe: 'కందిపప్పు (Red Gram / Pigeon Peas)',
    mean:   { N: 21,  P: 67, K: 19, pH: 5.8, temp: 27, humid: 49, rain: 150 },
    sigma:  { N: 15,  P: 25, K: 15, pH: 0.9, temp: 5,  humid: 15, rain: 60 },
    seasons: ['kharif'],
    soils: ['red', 'sandy loam', 'loam', 'black'],
    irrigation: ['rainfed', 'borewell'],
    notes: 'కందిపప్పు కరువు తట్టుకొనే పంట. మార్కెట్ ధర నిలకడగా ఉంటుంది.'
  },
  {
    nameEn: 'chickpea',
    nameTe: 'శనగ (Chickpea)',
    mean:   { N: 40,  P: 67, K: 79, pH: 7.1, temp: 18, humid: 17, rain: 73 },
    sigma:  { N: 20,  P: 25, K: 30, pH: 0.9, temp: 4,  humid: 10, rain: 30 },
    seasons: ['rabi'],
    soils: ['sandy loam', 'loam', 'red', 'clay'],
    irrigation: ['rainfed', 'borewell'],
    notes: 'శనగ రబీ సీజన్‌కు అనుకూలం. తక్కువ నీటితో మంచి దిగుబడి ఇస్తుంది.'
  },
  {
    nameEn: 'black gram',
    nameTe: 'మినుము (Black Gram / Urad)',
    mean:   { N: 40,  P: 67, K: 19, pH: 6.7, temp: 30, humid: 67, rain: 68 },
    sigma:  { N: 20,  P: 25, K: 15, pH: 0.8, temp: 4,  humid: 12, rain: 30 },
    seasons: ['kharif', 'rabi', 'other'],
    soils: ['loam', 'red', 'sandy loam'],
    irrigation: ['rainfed', 'borewell'],
    notes: 'మినుము 65–70 రోజులలో పంట తయారవుతుంది. ఉపాంత రైతులకు అనుకూలం.'
  },
  {
    nameEn: 'mung bean',
    nameTe: 'పెసర (Mung Bean / Green Gram)',
    mean:   { N: 21,  P: 47, K: 19, pH: 6.7, temp: 28, humid: 85, rain: 49 },
    sigma:  { N: 15,  P: 20, K: 15, pH: 0.8, temp: 4,  humid: 12, rain: 25 },
    seasons: ['kharif', 'other'],
    soils: ['sandy loam', 'loam', 'red'],
    irrigation: ['rainfed', 'borewell'],
    notes: 'పెసర వేగంగా పెరుగుతుంది. ఇతర పంటల మధ్య కూడా వేయవచ్చు.'
  },
  {
    nameEn: 'wheat',
    nameTe: 'గోధుమ (Wheat)',
    mean:   { N: 60,  P: 60, K: 60, pH: 6.5, temp: 15, humid: 55, rain: 70 },
    sigma:  { N: 25,  P: 25, K: 25, pH: 0.8, temp: 4,  humid: 12, rain: 30 },
    seasons: ['rabi'],
    soils: ['loam', 'clay', 'alluvial'],
    irrigation: ['canal', 'borewell'],
    notes: 'గోధుమ తక్కువ ఉష్ణోగ్రత, రబీ సీజన్‌లో బాగా పెరుగుతుంది.'
  },
  {
    nameEn: 'sunflower',
    nameTe: 'పొద్దుతిరుగుడు (Sunflower)',
    mean:   { N: 60,  P: 40, K: 40, pH: 6.5, temp: 25, humid: 50, rain: 55 },
    sigma:  { N: 25,  P: 20, K: 20, pH: 0.9, temp: 5,  humid: 15, rain: 25 },
    seasons: ['rabi', 'kharif'],
    soils: ['loam', 'sandy loam', 'red'],
    irrigation: ['borewell', 'rainfed'],
    notes: 'పొద్దుతిరుగుడు నూనె పంట. తక్కువ నీటితో మంచి ఆదాయం ఇస్తుంది.'
  },
  {
    nameEn: 'sorghum',
    nameTe: 'జొన్న (Sorghum)',
    mean:   { N: 50,  P: 25, K: 20, pH: 6.5, temp: 28, humid: 50, rain: 45 },
    sigma:  { N: 25,  P: 15, K: 15, pH: 1.0, temp: 5,  humid: 15, rain: 25 },
    seasons: ['kharif', 'rabi'],
    soils: ['red', 'sandy loam', 'loam', 'black'],
    irrigation: ['rainfed', 'borewell'],
    notes: 'జొన్న కరువు నిరోధక పంట. పశుగ్రాసంగా కూడా ఉపయోగపడుతుంది.'
  },
  {
    nameEn: 'pearl millet',
    nameTe: 'సజ్జ (Pearl Millet)',
    mean:   { N: 35,  P: 20, K: 15, pH: 7.0, temp: 32, humid: 45, rain: 40 },
    sigma:  { N: 20,  P: 15, K: 12, pH: 1.0, temp: 5,  humid: 15, rain: 20 },
    seasons: ['kharif'],
    soils: ['sandy', 'sandy loam', 'red'],
    irrigation: ['rainfed'],
    notes: 'సజ్జ అత్యంత కరువు తట్టుకొనే పంట. తేలికపాటి నేలలకు అనుకూలం.'
  },
  {
    nameEn: 'sugarcane',
    nameTe: 'చెరకు (Sugarcane)',
    mean:   { N: 100, P: 60, K: 80, pH: 6.5, temp: 30, humid: 70, rain: 180 },
    sigma:  { N: 35,  P: 25, K: 30, pH: 0.8, temp: 4,  humid: 12, rain: 60 },
    seasons: ['other'],
    soils: ['loam', 'clay', 'alluvial', 'black'],
    irrigation: ['canal', 'borewell', 'drip'],
    notes: 'చెరకు దీర్ఘకాలిక పంట (12–18 నెలలు). చక్కెర కర్మాగారాలకు మంచి డిమాండ్.'
  },
  {
    nameEn: 'chilli',
    nameTe: 'మిర్చి (Chilli)',
    mean:   { N: 80,  P: 50, K: 50, pH: 6.5, temp: 28, humid: 65, rain: 70 },
    sigma:  { N: 30,  P: 20, K: 20, pH: 0.8, temp: 4,  humid: 12, rain: 30 },
    seasons: ['kharif', 'rabi'],
    soils: ['loam', 'sandy loam', 'red'],
    irrigation: ['drip', 'borewell'],
    notes: 'ఆంధ్రప్రదేశ్ ప్రపంచ మిర్చి ఉత్పత్తిలో ముందు వరుసలో ఉంటుంది. ఎగుమతి అవకాశాలు ఎక్కువ.'
  },
  {
    nameEn: 'banana',
    nameTe: 'అరటి (Banana)',
    mean:   { N: 100, P: 82, K: 50, pH: 5.9, temp: 27, humid: 80, rain: 110 },
    sigma:  { N: 35,  P: 30, K: 25, pH: 0.8, temp: 3,  humid: 12, rain: 45 },
    seasons: ['other'],
    soils: ['loam', 'alluvial', 'clay'],
    irrigation: ['drip', 'borewell', 'canal'],
    notes: 'అరటి 11–12 నెలల పంట. ఏడాది మొత్తం మంచి ధర ఉంటుంది.'
  }
];

// ─── Standard deviations for feature weighting ───────────────────────────────
// Used when a crop doesn't explicitly define sigma for a feature
const DEFAULT_SIGMA = { N: 35, P: 30, K: 30, pH: 0.9, temp: 5, humid: 15, rain: 60 };

// Feature weights (how important each feature is in the final score)
const WEIGHTS = { N: 1.2, P: 1.0, K: 1.0, pH: 1.5, temp: 1.8, humid: 1.2, rain: 1.5 };

// ─── Gaussian scoring ─────────────────────────────────────────────────────────
function gaussianScore(value, mean, sigma) {
  return Math.exp(-Math.pow(value - mean, 2) / (2 * Math.pow(sigma, 2)));
}

// ─── Season / soil bonus multiplier ──────────────────────────────────────────
function contextBonus(crop, { season, soilType, irrigationType }) {
  let bonus = 1.0;
  const s = (season || '').toLowerCase();
  const soil = (soilType || '').toLowerCase();
  const irr = (irrigationType || '').toLowerCase();

  if (s && crop.seasons.some((cs) => cs === s)) bonus += 0.15;
  if (soil && crop.soils.some((cs) => soil.includes(cs) || cs.includes(soil))) bonus += 0.10;
  if (irr && crop.irrigation.some((ci) => irr.includes(ci) || ci.includes(irr))) bonus += 0.10;

  return Math.min(bonus, 1.35); // cap bonus at 35%
}

// ─── Main recommendation function ────────────────────────────────────────────
/**
 * @param {object} features  - { N, P, K, pH, temp, humid, rain } (all optional)
 * @param {object} context   - { season, soilType, irrigationType, landSizeAcres }
 * @param {number} topN      - number of crops to return (default 5)
 * @returns {Array}          - sorted recommendation objects
 */
function recommendCrops(features, context = {}, topN = 5) {
  const featureKeys = ['N', 'P', 'K', 'pH', 'temp', 'humid', 'rain'];
  const providedKeys = featureKeys.filter((k) => features[k] !== null && features[k] !== undefined);

  if (!providedKeys.length) {
    // Fall back to season/soil/irrigation heuristic when no numeric features given
    return fallbackRules(context, topN);
  }

  const totalWeight = providedKeys.reduce((sum, k) => sum + (WEIGHTS[k] || 1), 0);

  const scored = CROP_DB.map((crop) => {
    let weightedScore = 0;

    providedKeys.forEach((key) => {
      const mean  = crop.mean[key];
      const sigma = crop.sigma[key] || DEFAULT_SIGMA[key];
      const g = gaussianScore(Number(features[key]), mean, sigma);
      weightedScore += g * (WEIGHTS[key] || 1);
    });

    const rawScore = weightedScore / totalWeight;          // 0–1
    const adjusted = rawScore * contextBonus(crop, context); // apply context bonus
    const confidence = Math.min(Math.round(adjusted * 100), 99); // as percentage

    return { crop, confidence };
  });

  // Sort by confidence descending, return top N
  return scored
    .sort((a, b) => b.confidence - a.confidence)
    .slice(0, topN)
    .filter((r) => r.confidence > 5); // filter out clearly unsuitable crops
}

// ─── Fallback rules (no numeric features) ────────────────────────────────────
function fallbackRules({ season, soilType, irrigationType }, topN) {
  const s    = (season || '').toLowerCase();
  const soil = (soilType || '').toLowerCase();
  const irr  = (irrigationType || '').toLowerCase();

  const ranked = CROP_DB.map((crop) => {
    let score = 0;
    if (s    && crop.seasons.some((cs) => cs === s)) score += 40;
    if (soil && crop.soils.some((cs) => soil.includes(cs) || cs.includes(soil))) score += 35;
    if (irr  && crop.irrigation.some((ci) => irr.includes(ci) || ci.includes(irr))) score += 25;
    return { crop, confidence: score };
  });

  return ranked
    .sort((a, b) => b.confidence - a.confidence)
    .slice(0, topN)
    .filter((r) => r.confidence > 0);
}

// ─── Economics estimator (kept from original, extended) ──────────────────────
const ECONOMICS_DB = {
  paddy:        { yieldPerAcre: 25, pricePerQuintal: 2200, costPerAcre: 25000 },
  maize:        { yieldPerAcre: 20, pricePerQuintal: 1800, costPerAcre: 20000 },
  cotton:       { yieldPerAcre: 8,  pricePerQuintal: 6500, costPerAcre: 30000 },
  'red gram':   { yieldPerAcre: 7,  pricePerQuintal: 7000, costPerAcre: 18000 },
  chickpea:     { yieldPerAcre: 8,  pricePerQuintal: 6000, costPerAcre: 17000 },
  'black gram': { yieldPerAcre: 6,  pricePerQuintal: 6500, costPerAcre: 16000 },
  'mung bean':  { yieldPerAcre: 5,  pricePerQuintal: 7000, costPerAcre: 15000 },
  groundnut:    { yieldPerAcre: 12, pricePerQuintal: 5500, costPerAcre: 22000 },
  wheat:        { yieldPerAcre: 20, pricePerQuintal: 2100, costPerAcre: 19000 },
  sunflower:    { yieldPerAcre: 8,  pricePerQuintal: 5000, costPerAcre: 21000 },
  sorghum:      { yieldPerAcre: 10, pricePerQuintal: 2500, costPerAcre: 15000 },
  'pearl millet':{ yieldPerAcre: 9, pricePerQuintal: 2200, costPerAcre: 13000 },
  sugarcane:    { yieldPerAcre: 300, pricePerQuintal: 300, costPerAcre: 80000 },
  chilli:       { yieldPerAcre: 15, pricePerQuintal: 8000, costPerAcre: 45000 },
  banana:       { yieldPerAcre: 120, pricePerQuintal: 1200, costPerAcre: 60000 }
};

function estimateEconomicsML(cropNameEn, landSizeAcres) {
  const area    = Number(landSizeAcres) || 1;
  const data    = ECONOMICS_DB[cropNameEn] || { yieldPerAcre: 10, pricePerQuintal: 2000, costPerAcre: 20000 };
  const totalYield   = data.yieldPerAcre * area;
  const grossIncome  = totalYield * data.pricePerQuintal;
  const totalCost    = data.costPerAcre * area;
  const netProfit    = grossIncome - totalCost;
  return { yieldPerAcre: data.yieldPerAcre, totalYieldQuintals: totalYield,
           pricePerQuintal: data.pricePerQuintal, grossIncome,
           costPerAcre: data.costPerAcre, totalCost, netProfit, areaAcres: area };
}

module.exports = { recommendCrops, estimateEconomicsML, CROP_DB };
