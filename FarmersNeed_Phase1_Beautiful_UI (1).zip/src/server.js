const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const axios = require('axios');
const path = require('path');
const crypto = require('crypto');
const { DatabaseSync } = require('node:sqlite');
const { recommendCrops, estimateEconomicsML } = require('./mlRecommender');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

const allowedOrigins = (process.env.ALLOWED_ORIGINS || '').split(',').map(x => x.trim()).filter(Boolean);
app.disable('x-powered-by');
app.use(cors({ origin(origin, cb) { cb(null, !origin || allowedOrigins.includes(origin)); } }));
app.use(express.json({ limit: '32kb' }));
app.use((req, res, next) => { res.setHeader('X-Content-Type-Options', 'nosniff'); res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin'); next(); });
const db = new DatabaseSync(process.env.DB_PATH || path.join(__dirname, '..', 'farmersneed.sqlite'));
db.exec(`CREATE TABLE IF NOT EXISTS bookings (id TEXT PRIMARY KEY, payload TEXT NOT NULL, secret_hash TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS profiles (phone TEXT PRIMARY KEY, payload TEXT NOT NULL);`);
const hash = x => crypto.createHash('sha256').update(String(x)).digest('hex');
function safeEqual(a,b) { const x=Buffer.from(String(a)), y=Buffer.from(String(b)); return x.length===y.length && crypto.timingSafeEqual(x,y); }
function isAdmin(req) { const key=process.env.ADMIN_API_KEY; return !!key && safeEqual(req.get('x-admin-key') || '', key); }
function adminOnly(req,res,next) { if (!isAdmin(req)) return res.status(403).json({error:'Admin authorization required'}); next(); }
function ownerOrAdmin(req,booking) { const row=db.prepare('SELECT secret_hash FROM bookings WHERE id=?').get(booking.id); return isAdmin(req) || !!row && !!req.get('x-booking-token') && safeEqual(hash(req.get('x-booking-token')),row.secret_hash); }
function saveBooking(b) { db.prepare('UPDATE bookings SET payload=? WHERE id=?').run(JSON.stringify(b),b.id); }


app.use(express.static(path.join(__dirname, '..', 'public')));

// --- Simple in-memory ads and content data ---
const ADS = [
  {
    id: 1,
    titleTe: 'ఉత్తమ నాణ్యమైన వరి విత్తనాలు',
    descriptionTe: 'ప్రమాణిత కంపెనీ నుండి అధిక దిగుబడి వరి విత్తనాలు.',
    imageUrl: 'https://example.com/images/rice-seeds.png',
    ctaTextTe: 'ఇంకా తెలుసుకోండి',
    ctaUrl: 'https://example.com/products/rice-seeds'
  },
  {
    id: 2,
    titleTe: 'డ్రిప్ ఇరిగేషన్ సెట్స్',
    descriptionTe: 'నీటి ఆదా, అధిక దిగుబడి కోసం డ్రిప్ సిస్టమ్.',
    imageUrl: 'https://example.com/images/drip-system.png',
    ctaTextTe: 'ఇప్పుడే సంప్రదించండి',
    ctaUrl: 'https://example.com/products/drip-irrigation'
  }
];

// Simple in-memory storage for ad/branding requests (for production use a DB)
const AD_REQUESTS = [];

// Simple in-memory storage for worker requests
const WORKER_REQUESTS = [];

// Simple in-memory discussion data (for production use a DB)
const DISCUSSION_POSTS = [];
const DISCUSSION_COMMENTS = [];

const CONTENT_ITEMS = [
  {
    id: 1,
    titleTe: 'ఒక ఎకరంలో వరి దిగుబడిని ఎలా పెంచాలి?',
    summaryTe: 'సమయానికి నాట్లు నాటడం, సమయానికి ఎరువులు వేయడం, నీటి నిర్వహణను సవ్యంగా చేయడం ద్వారా వరి దిగుబడిని పెంచవచ్చు.',
    fullContentTe: `వరి దిగుబడి పెంచడానికి ముఖ్యమైన చర్యలు:\n\n• నాట్లు నాటడం: సీజన్ ప్రారంభంలో 20–25 రోజుల మొక్కలను నాటాలి. విత్తన రకాలు MTU 1010, BPT 5204 అధిక దిగుబడినిస్తాయి.\n\n• ఎరువుల నిర్వహణ: ఒక ఎకరాకు 50 కిలోల నత్రజని, 25 కిలోల భాస్వరం, 25 కిలోల పొటాష్ అవసరం. మూడు దఫాలుగా వేయాలి.\n\n• నీటి నిర్వహణ: పూత దశలో నీరు తప్పనిసరి. రోజూ 5 సె.మీ. లోతు నీరు అవసరం.\n\n• కలుపు నిర్వహణ: నాట్ల తర్వాత 15–20 రోజులలో కలుపు తీయాలి.\n\n• పురుగు నిర్వహణ: కాండం తొలుచు పురుగు కనిపిస్తే వెంటనే మందు పిచికారీ చేయండి.\n\nఈ చర్యల ద్వారా ఎకరాకు 30–35 బస్తాల వరకు దిగుబడి పొందవచ్చు.`,
    category: 'paddy',
    sourceLabelTe: 'ఆనాదాతా శైలి వ్యాసం'
  },
  {
    id: 2,
    titleTe: 'తక్కువ నీటితో పెరుగు పంటలు',
    summaryTe: 'శనగ, పెసర, మినుము వంటి పంటలు తక్కువ నీటితో కూడా మంచి దిగుబడి ఇస్తాయి.',
    fullContentTe: `తక్కువ నీటితో మంచి ఫలితం ఇచ్చే పంటలు:\n\n• శనగ (Chickpea): వర్షాధారిత ప్రాంతాలకు అనుకూలం. ఒక ఎకరాకు 6–8 క్వింటాళ్లు దిగుబడి. నీటి తడి 2–3 సార్లు మాత్రమే అవసరం.\n\n• పెసర (Green Gram): 60–65 రోజులలో పంట తయారవుతుంది. ఒక ఎకరాకు 4–5 క్వింటాళ్లు.\n\n• మినుము (Black Gram): అల్ప వర్షపాతం ఉన్న ప్రాంతాల్లో బాగా పెరుగుతుంది. ఒక ఎకరాకు 4–6 క్వింటాళ్లు.\n\n• జొన్న (Sorghum): చాలా కరువు తట్టుకొనే పంట. పశుగ్రాసంగా కూడా ఉపయోగపడుతుంది.\n\nఈ పంటలు వేసవిలో లేదా రబీ సీజన్‌లో వేయడం లాభదాయకం. నేల తేమ నిల్వకు మల్చింగ్ ఉపయోగించండి.`,
    category: 'pulses',
    sourceLabelTe: 'ఆనాదాతా శైలి వ్యాసం'
  },
  {
    id: 3,
    titleTe: 'పత్తి పంటలో పురుగుల నిర్వహణ',
    summaryTe: 'బోల్‌వార్మ్ మరియు థ్రిప్స్ వంటి పురుగులు పత్తి దిగుబడిని తగ్గిస్తాయి. సకాలంలో నిర్వహణ ద్వారా నష్టాన్ని తగ్గించవచ్చు.',
    fullContentTe: `పత్తి పురుగుల నిర్వహణ — పూర్తి వివరాలు:\n\n• అమెరికన్ బోల్‌వార్మ్: గులాబీ రంగు లార్వాలు గింజలను తింటాయి. ఫెరొమోన్ ట్రాప్‌లు పెట్టండి. BT మందు పిచికారీ చేయండి.\n\n• థ్రిప్స్: ఆకుల అడుగు భాగంలో ఉంటాయి. ఆకులు వంకరగా మారతాయి. స్పినోసాడ్ మందు వాడండి.\n\n• వైట్‌ఫ్లై: వైరస్ వ్యాధులను వ్యాపింపజేస్తాయి. పసుపు రంగు స్టిక్కీ ట్రాప్‌లు పెట్టండి.\n\n• మీలీబగ్: తెల్లని దూది వంటి పురుగులు. క్లోర్పైరిఫాస్ మందు వాడండి.\n\nముఖ్యమైన సూచన: ఏ మందు వాడినా ముందు వ్యవసాయ అధికారిని సంప్రదించండి. IPM పద్ధతులు అనుసరించడం మంచిది.`,
    category: 'cotton',
    sourceLabelTe: 'రైతు మిత్ర వ్యవసాయ సలహా'
  },
  {
    id: 4,
    titleTe: 'నేల ఆరోగ్యం — మట్టి పరీక్ష ఎందుకు అవసరం?',
    summaryTe: 'ప్రతి 3 సంవత్సరాలకు ఒకసారి నేల పరీక్ష చేయించుకోవడం వల్ల ఎరువుల ఖర్చు తగ్గి దిగుబడి పెరుగుతుంది.',
    fullContentTe: `నేల పరీక్ష — ఎందుకు, ఎలా:\n\n• నేల పరీక్ష అవసరం ఎందుకు?\nఒక్కో నేలకు వేరు వేరు పోషకాలు అవసరం. తక్కువ అవసరమైన ఎరువు వేస్తే నష్టం, ఎక్కువ వేస్తే ఖర్చు పెరుగుతుంది.\n\n• నమూనా ఎప్పుడు తీయాలి?\nపంట కోత తర్వాత లేదా విత్తనాలు వేయడానికి ముందు తీయాలి.\n\n• నమూనా ఎలా తీయాలి?\nపొలంలో 8–10 చోట్ల V ఆకారంలో 15 సె.మీ. లోతు మట్టి తీసి కలపాలి.\n\n• పరీక్ష ఎక్కడ చేయించాలి?\nజిల్లా వ్యవసాయ కార్యాలయం, ICAR సంస్థలు, ప్రైవేట్ ల్యాబులలో చేయించవచ్చు. ఖర్చు సుమారు ₹100–300.\n\n• ఫలితాలు వస్తే ఏం చేయాలి?\nరిపోర్ట్‌లో చెప్పిన మోతాదులో మాత్రమే ఎరువులు వేయాలి. అవసరమైతే సున్నం వేసి pH సరిచేయాలి.`,
    category: 'soil',
    sourceLabelTe: 'ఆంధ్రప్రదేశ్ వ్యవసాయ శాఖ'
  },
  {
    id: 5,
    titleTe: 'ప్రభుత్వ పథకాలు — PM-KISAN మరియు రైతు భరోసా',
    summaryTe: 'PM-KISAN కింద ₹6,000/సంవత్సరం మరియు రైతు భరోసా ద్వారా అదనపు సహాయం పొందవచ్చు.',
    fullContentTe: `రైతులకు ముఖ్యమైన ప్రభుత్వ పథకాలు:\n\n• PM-KISAN (ప్రధాన మంత్రి కిసాన్ సమ్మాన్ నిధి):\n– సంవత్సరానికి ₹6,000 మూడు వాయిదాలలో నేరుగా బ్యాంకు ఖాతాకు జమ అవుతాయి.\n– అర్హత: 2 హెక్టార్ల లోపు భూమి ఉన్న రైతులు.\n– దరఖాస్తు: pmkisan.gov.in లేదా CSC కేంద్రంలో.\n\n• రైతు భరోసా (AP):\n– ఇన్‌పుట్ సహాయంగా ఎకరాకు ₹13,500 వరకు.\n– పంట నష్టానికి బీమా సహాయం.\n\n• పంట బీమా (PMFBY):\n– కనీస ప్రీమియంతో పంట నష్టానికి పూర్తి పరిహారం.\n– దరఖాస్తు: విత్తన కాలంలో బ్యాంకులో చేయించాలి.\n\n• కిసాన్ క్రెడిట్ కార్డు:\n– తక్కువ వడ్డీకి పంట రుణం.\n– బ్యాంకులో దరఖాస్తు చేయవచ్చు.\n\nఈ పథకాల కోసం ఆధార్, భూ రికార్డులు, బ్యాంకు పాస్‌బుక్ సిద్ధంగా ఉంచుకోండి.`,
    category: 'schemes',
    sourceLabelTe: 'ప్రభుత్వ పథకాల సమాచారం'
  },
  {
    id: 6,
    titleTe: 'మొక్కజొన్న పంటలో నీటి నిర్వహణ',
    summaryTe: 'మొక్కజొన్న పువ్వు వేళ మరియు గింజ నిండే సమయంలో నీరు తప్పనిసరి. ఒక ఎకరాకు సుమారు 500–600 మి.మీ. నీరు అవసరం.',
    fullContentTe: `మొక్కజొన్న నీటి నిర్వహణ — పూర్తి గైడ్:\n\n• విత్తన సమయం: విత్తనాలు నాటిన వెంటనే ఒక తడి అవసరం.\n\n• పెరుగుదల దశ: వారానికి ఒకసారి తడి అవసరం. నేల తడి ఉన్నప్పుడు తడి వేయకూడదు.\n\n• పువ్వు దశ (Tasseling): ఇది అత్యంత క్లిష్టమైన దశ. నీరు లేకపోతే దిగుబడి 50% తగ్గవచ్చు. 4–5 రోజులకు ఒక తడి వేయాలి.\n\n• గింజ నిండే దశ: 10 రోజులకు ఒకసారి తడి వేయాలి.\n\n• కోత ముందు: కోతకు 15 రోజుల ముందు తడి ఆపాలి.\n\n• మల్చింగ్: వర్షాధారిత ప్రాంతాల్లో వరి పొట్టు లేదా పప్పు తొక్కలతో మల్చింగ్ చేయడం వల్ల తేమ నిల్వ ఉంటుంది.\n\nడ్రిప్ ఇరిగేషన్ వాడితే 30–40% నీరు ఆదా అవుతుంది.`,
    category: 'maize',
    sourceLabelTe: 'రైతు మిత్ర వ్యవసాయ సలహా'
  },
  {
    id: 7,
    titleTe: 'సేంద్రీయ వ్యవసాయం — అవకాశాలు మరియు సవాళ్లు',
    summaryTe: 'రసాయన ఎరువులను తగ్గించి జీవన ఎరువులు, కంపోస్ట్ వాడడం ద్వారా నేల జీవశక్తి పెరుగుతుంది. ధృవీకరించిన రైతులకు 20–30% అధిక ధర లభిస్తుంది.',
    fullContentTe: `సేంద్రీయ వ్యవసాయం — పూర్తి సమాచారం:\n\n• సేంద్రీయ వ్యవసాయం అంటే ఏమిటి?\nరసాయన ఎరువులు, పురుగు మందులు వాడకుండా సహజ పద్ధతులలో వ్యవసాయం చేయడం.\n\n• ఉపయోగాలు:\n– నేల ఆరోగ్యం మెరుగవుతుంది\n– ఉత్పత్తికి అధిక ధర లభిస్తుంది\n– ఎరువుల ఖర్చు తగ్గుతుంది\n– పర్యావరణానికి మేలు\n\n• ఏం వాడాలి:\n– వర్మీకంపోస్ట్ (వానపాముల ఎరువు)\n– జీవన ఎరువులు (Rhizobium, Azospirillum)\n– వేప కషాయం (పురుగులకు)\n– గోమూత్రం, పంచగవ్య\n\n• ధృవీకరణ పొందడం ఎలా?\nPGS India లేదా NPOP ద్వారా సేంద్రీయ ధృవీకరణ పొందవచ్చు. దరఖాస్తు: aporganicfarming.ap.gov.in\n\n• మార్కెట్ అవకాశాలు:\nహైదరాబాద్, విజయవాడ నగరాల్లో సేంద్రీయ ఉత్పత్తులకు మంచి డిమాండ్ ఉంది.`,
    category: 'organic',
    sourceLabelTe: 'జాతీయ సేంద్రీయ వ్యవసాయ కేంద్రం'
  },
  {
    id: 8,
    titleTe: 'ఖరీఫ్ 2026 — ఏ పంట వేయాలి?',
    summaryTe: 'నల్ల నేలల్లో పత్తి, ఎర్ర నేలల్లో వేరుశనగ లాభదాయకం. వరి ధర మద్దతు ధర కంటే ఎక్కువగా ఉంటుందని అంచనా.',
    fullContentTe: `ఖరీఫ్ 2026 పంట ప్రణాళిక:\n\n• నల్ల నేలలు (బ్లాక్ సాయిల్):\n– పత్తి: అత్యంత లాభదాయకం. BT పత్తి రకాలు వేయండి.\n– రెడ్ గ్రామ్ (కందిపప్పు): 150–180 రోజులు. మార్కెట్ ధర బాగుంది.\n\n• ఎర్ర నేలలు (రెడ్ సాయిల్):\n– వేరుశనగ: నూనె కంపెనీలకు మంచి డిమాండ్. ఒక ఎకరాకు 8–12 క్వింటాళ్లు.\n– పెసర / మినుము: తక్కువ ఖర్చు, తొందరగా పంట.\n\n• నీటి పారుదల ఉంటే:\n– వరి (BPT 5204): MSP ₹2,300/క్వింటాల్ అంచనా.\n– మొక్కజొన్న: పౌల్ట్రీ, పశు ఆహారానికి డిమాండ్ ఎక్కువ.\n\n• జాగ్రత్తలు:\n– విత్తనాలు ముందే కొనండి (ఏప్రిల్–మేలో).\n– వాతావరణ అంచనాలు చూసి నిర్ణయం తీసుకోండి.\n– స్థానిక మార్కెట్ ధరలు తెలుసుకోండి.`,
    category: 'kharif',
    sourceLabelTe: 'ఆనాదాతా మార్కెట్ విశ్లేషణ 2026'
  },
  {
    id: 9,
    titleTe: 'డ్రిప్ ఇరిగేషన్ — నీటి ఆదా, ఎక్కువ దిగుబడి',
    summaryTe: 'సాంప్రదాయ పారుదల కంటే డ్రిప్ పద్ధతిలో 40–50% నీరు ఆదా అవుతుంది. AP ప్రభుత్వం 90% వరకు సబ్సిడీ అందిస్తోంది.',
    fullContentTe: `డ్రిప్ ఇరిగేషన్ పూర్తి సమాచారం:\n\n• డ్రిప్ ఇరిగేషన్ ఎలా పనిచేస్తుంది?\nపైపుల ద్వారా నేరుగా మొక్క వేరుకు నీరు అందిస్తుంది. బొట్టు బొట్టుగా నీరు ఇవ్వడం వల్ల వృథా తగ్గుతుంది.\n\n• ప్రయోజనాలు:\n– 40–50% నీరు ఆదా\n– 20–30% దిగుబడి పెరుగుదల\n– కలుపు మొక్కలు తక్కువగా పెరుగుతాయి\n– ఎరువులు నీటితో కలిపి ఇవ్వవచ్చు (Fertigation)\n\n• ఖర్చు:\nఒక ఎకరాకు ₹30,000–50,000 ఖర్చవుతుంది.\n\n• సబ్సిడీ:\nAP ప్రభుత్వం 90% వరకు సబ్సిడీ ఇస్తోంది. SC/ST రైతులకు పూర్తి సబ్సిడీ.\n\n• దరఖాస్తు ఎక్కడ?\nస్థానిక వ్యవసాయ కార్యాలయంలో లేదా horticulture.ap.gov.in లో దరఖాస్తు చేయవచ్చు.\n\n• ఏ పంటలకు అనుకూలం?\nమిర్చి, టమాటా, వంకాయ, పత్తి, మొక్కజొన్న, అరటి.`,
    category: 'irrigation',
    sourceLabelTe: 'AP హార్టికల్చర్ డిపార్ట్‌మెంట్'
  },
  {
    id: 10,
    titleTe: 'పంట అమ్మకం — మండీ vs ఆన్‌లైన్ మార్కెట్ (e-NAM)',
    summaryTe: 'e-NAM పోర్టల్ ద్వారా పంటలను ఆన్‌లైన్‌లో వేలం వేయవచ్చు. మండీ కంటే 5–15% అధిక ధర పొందే అవకాశం.',
    fullContentTe: `పంట అమ్మకం — అన్ని మార్గాలు:\n\n• సాంప్రదాయ మండీ:\n– దగ్గరలో ఉంటుంది, తక్షణ చెల్లింపు.\n– కానీ దళారుల వల్ల ధర తగ్గవచ్చు.\n– APMC లైసెన్స్ ఉన్న వ్యాపారులతో మాత్రమే వ్యవహారం.\n\n• e-NAM (ఎలక్ట్రానిక్ నేషనల్ అగ్రికల్చర్ మార్కెట్):\n– ఆన్‌లైన్‌లో దేశవ్యాప్తంగా కొనుగోలుదారులు.\n– రిజిస్ట్రేషన్: enam.gov.in లో ఉచితంగా చేయవచ్చు.\n– నగదు నేరుగా బ్యాంకు ఖాతాకు.\n\n• FPO (రైతు ఉత్పత్తి సంఘాలు):\n– సంఘంగా అమ్మడం వల్ల ధర బాగుంటుంది.\n– రవాణా ఖర్చు తగ్గుతుంది.\n\n• ప్రత్యక్ష విక్రయం:\n– నగర మార్కెట్లలో నేరుగా అమ్మడం.\n– సేంద్రీయ ఉత్పత్తులకు ఈ పద్ధతి బాగుంటుంది.\n\nసూచన: ధర పోల్చి అమ్మండి. మండీలో అమ్మే ముందు ఆ రోజు ధర తెలుసుకోండి.`,
    category: 'market',
    sourceLabelTe: 'e-NAM రైతు సేవా కేంద్రం'
  }
];

// --- Utility functions ---

async function fetchWeather(lat, lon) {
  const apiKey = process.env.OPENWEATHER_API_KEY;
  if (!apiKey || !lat || !lon) {
    return null;
  }

  try {
    const url = `https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`;
    const { data } = await axios.get(url);
    return data;
  } catch (err) {
    console.error('Error fetching weather:', err.message);
    return null;
  }
}

function summarizeWeather(forecast) {
  if (!forecast || !Array.isArray(forecast.list) || !forecast.list.length) {
    return null;
  }

  const first = forecast.list[0];
  const current = {
    time: first.dt_txt,
    temp: first.main?.temp,
    feelsLike: first.main?.feels_like,
    humidity: first.main?.humidity,
    windSpeed: first.wind?.speed,
    description: first.weather?.[0]?.description
  };

  // Pick one entry per day (every ~24h -> step 8 for 3‑hour data)
  const daily = [];
  for (let i = 0; i < forecast.list.length; i += 8) {
    const item = forecast.list[i];
    if (!item) continue;
    daily.push({
      time: item.dt_txt,
      temp: item.main?.temp,
      humidity: item.main?.humidity,
      description: item.weather?.[0]?.description
    });
  }

  return { current, daily };
}

async function reverseGeocode(lat, lon) {
  if (!lat || !lon) {
    return null;
  }

  try {
    // Using OpenStreetMap Nominatim (no key required, but respect usage limits in production)
    const url = `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lon}&format=json&addressdetails=1`;
    const { data } = await axios.get(url, {
      headers: {
        'User-Agent': 'telugu-farmer-assistant/1.0'
      }
    });

    const address = data.address || {};

    // Nominatim returns different keys, map to our fields
    const district =
      address.county ||
      address.state_district ||
      address.city_district ||
      address.city ||
      address.state ||
      null;
    const mandal = address.suburb || address.village || address.town || null;
    const village = address.village || address.hamlet || address.suburb || null;

    return {
      raw: data,
      district,
      mandal,
      village,
      displayName: data.display_name
    };
  } catch (err) {
    console.error('Error in reverseGeocode:', err.response?.data || err.message);
    return null;
  }
}

async function callLLMForTeluguExplanation(payload) {
  const url = process.env.LLM_API_URL;
  const apiKey = process.env.LLM_API_KEY;

  if (!url || !apiKey) {
    return null;
  }

  try {
    const { data } = await axios.post(
      url,
      {
        prompt:
          'Explain these crop recommendations and profit details in very simple Telugu language suitable for farmers. ' +
          'Use short sentences and bullet points. Input JSON: ' +
          JSON.stringify(payload),
        max_tokens: 512
      },
      {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${apiKey}`
        }
      }
    );

    // Adjust this depending on your LLM provider's response format
    return data.choices?.[0]?.message?.content || data.text || null;
  } catch (err) {
    console.error('Error calling LLM:', err.response?.data || err.message);
    return null;
  }
}

function basicCropRules({ season, soilType, irrigationType }) {
  const crops = [];

  const s = (season || '').toLowerCase();
  const soil = (soilType || '').toLowerCase();
  const irr = (irrigationType || '').toLowerCase();

  if (s === 'kharif') {
    if (soil.includes('black')) {
      crops.push('cotton', 'red gram');
    } else {
      crops.push('paddy', 'maize');
    }
  } else if (s === 'rabi') {
    if (soil.includes('red')) {
      crops.push('groundnut', 'sunflower');
    } else {
      crops.push('wheat', 'chickpea');
    }
  } else {
    crops.push('vegetables', 'pulses');
  }

  if (irr.includes('rainfed')) {
    crops.push('millets');
  }

  // Remove duplicates
  return [...new Set(crops)];
}

function estimateEconomics(crop, landSizeAcres) {
  // Very rough sample numbers, replace with real data for production
  const base = {
    paddy: { yieldPerAcre: 25, pricePerQuintal: 2200, costPerAcre: 25000 },
    maize: { yieldPerAcre: 20, pricePerQuintal: 1800, costPerAcre: 20000 },
    cotton: { yieldPerAcre: 8, pricePerQuintal: 6500, costPerAcre: 30000 },
    'red gram': { yieldPerAcre: 7, pricePerQuintal: 7000, costPerAcre: 18000 },
    groundnut: { yieldPerAcre: 12, pricePerQuintal: 5500, costPerAcre: 22000 },
    sunflower: { yieldPerAcre: 8, pricePerQuintal: 5000, costPerAcre: 21000 },
    wheat: { yieldPerAcre: 20, pricePerQuintal: 2100, costPerAcre: 19000 },
    chickpea: { yieldPerAcre: 8, pricePerQuintal: 6000, costPerAcre: 17000 },
    millets: { yieldPerAcre: 10, pricePerQuintal: 2500, costPerAcre: 15000 },
    pulses: { yieldPerAcre: 8, pricePerQuintal: 5500, costPerAcre: 17000 },
    vegetables: { yieldPerAcre: 60, pricePerQuintal: 1500, costPerAcre: 40000 }
  };

  const key = crop.toLowerCase();
  const defaults = base[key] || { yieldPerAcre: 10, pricePerQuintal: 2000, costPerAcre: 20000 };

  const area = Number(landSizeAcres) || 1;
  const totalYieldQuintals = defaults.yieldPerAcre * area;
  const grossIncome = totalYieldQuintals * defaults.pricePerQuintal;
  const totalCost = defaults.costPerAcre * area;
  const netProfit = grossIncome - totalCost;

  return {
    crop,
    areaAcres: area,
    yieldPerAcre: defaults.yieldPerAcre,
    totalYieldQuintals,
    pricePerQuintal: defaults.pricePerQuintal,
    grossIncome,
    costPerAcre: defaults.costPerAcre,
    totalCost,
    netProfit
  };
}

// --- Routes ---

// Health check
app.get('/health', (_req, res) => {
  res.json({ status: 'ok', message: 'Telugu farmer API running' });
});

// Simple weather endpoint for UI
app.get('/api/weather', async (req, res) => {
  try {
    const lat = Number(req.query.lat);
    const lon = Number(req.query.lon);
    if (!lat || !lon) {
      return res.status(400).json({ error: 'lat and lon query params are required' });
    }

    const [forecast, reverseGeo] = await Promise.all([
      fetchWeather(lat, lon),
      reverseGeocode(lat, lon)
    ]);

    // If OpenWeather fetch failed (missing/invalid key or provider error), return a clear error
    if (!forecast) {
      return res.status(502).json({
        error: 'Weather provider unavailable',
        messageTe:
          'వాతావరణ డేటా తెచ్చుకోలేకపోయాం. OPENWEATHER_API_KEY సరి ఉందా (లేదా సెట్ చేశారా) చెక్ చేయండి.',
        hint:
          'Create .env and set OPENWEATHER_API_KEY, then restart the server. Also ensure internet access.'
      });
    }

    const summary = summarizeWeather(forecast);

    res.json({
      location: {
        lat,
        lon,
        district: reverseGeo?.district || null,
        mandal: reverseGeo?.mandal || null,
        village: reverseGeo?.village || null,
        displayName: reverseGeo?.displayName || null
      },
      summary,
      raw: forecast
    });
  } catch (err) {
    console.error('Error in /api/weather:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Crop recommendation + profit based on rules and basic economics, plus optional Telugu AI summary
app.post('/api/recommendations', async (req, res) => {
  try {
    const {
      district,
      mandal,
      village,
      lat,
      lon,
      landSizeAcres,
      soilType,
      irrigationType,
      season
    } = req.body || {};

    // If location names not provided but coordinates are, reverse geocode
    let resolvedDistrict = district;
    let resolvedMandal = mandal;
    let resolvedVillage = village;
    let reverseGeo = null;

    if ((!district || !mandal || !village) && lat && lon) {
      reverseGeo = await reverseGeocode(lat, lon);
      if (reverseGeo) {
        resolvedDistrict = resolvedDistrict || reverseGeo.district;
        resolvedMandal = resolvedMandal || reverseGeo.mandal;
        resolvedVillage = resolvedVillage || reverseGeo.village;
      }
    }

    const weather = await fetchWeather(lat, lon);
    const crops = basicCropRules({ season, soilType, irrigationType });
    const economics = crops.map((crop) => estimateEconomics(crop, landSizeAcres));

    const baseResponse = {
      location: {
        district: resolvedDistrict,
        mandal: resolvedMandal,
        village: resolvedVillage,
        lat,
        lon,
        reverseGeocode: reverseGeo
      },
      season,
      soilType,
      irrigationType,
      weather,
      recommendations: economics
    };

    // Try to get a Telugu explanation from LLM (if configured)
    const teluguExplanation = await callLLMForTeluguExplanation(baseResponse);

    res.json({
      ...baseResponse,
      teluguExplanation:
        teluguExplanation ||
        'క్రింది పంట సూచనలు మీ భూమి విస్తీర్ణం, నేల రకం, నీరు పరిస్థితి, సీజన్ ఆధారంగా లెక్కించబడ్డాయి.'
    });
  } catch (err) {
    console.error('Error in /api/recommendations:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ML-based Crop Recommendation endpoint
app.post('/api/ml/recommend', async (req, res) => {
  try {
    const {
      N, P, K, pH, temp, humid, rain,
      season, soilType, irrigationType,
      landSizeAcres, lat, lon,
      district, mandal, village
    } = req.body || {};

    const features = {};
    if (N    !== undefined && N    !== '') features.N    = Number(N);
    if (P    !== undefined && P    !== '') features.P    = Number(P);
    if (K    !== undefined && K    !== '') features.K    = Number(K);
    if (pH   !== undefined && pH   !== '') features.pH   = Number(pH);
    if (temp !== undefined && temp !== '') features.temp = Number(temp);
    if (humid!== undefined && humid!== '') features.humid= Number(humid);
    if (rain !== undefined && rain !== '') features.rain = Number(rain);

    const context = { season, soilType, irrigationType };
    const ranked  = recommendCrops(features, context, 5);

    const recommendations = ranked.map(({ crop, confidence }) => ({
      cropEn:     crop.nameEn,
      cropTe:     crop.nameTe,
      confidence,
      notes:      crop.notes,
      suitableSeasons: crop.seasons,
      suitableSoils:   crop.soils,
      economics:  estimateEconomicsML(crop.nameEn, landSizeAcres || 1)
    }));

    // Fetch weather if location given
    let weather = null;
    if (lat && lon) {
      weather = await fetchWeather(Number(lat), Number(lon));
    }

    const featuresUsed = Object.keys(features);

    res.json({
      mlEngine:   'Gaussian Weighted Scoring (Naive Bayes style)',
      featuresUsed,
      inputFeatures: features,
      context:    { season, soilType, irrigationType, landSizeAcres, district, mandal, village },
      weather,
      recommendations,
      teluguNote: featuresUsed.length
        ? `మీరు అందించిన ${featuresUsed.length} నేల / వాతావరణ వివరాల ఆధారంగా ML అల్గారిథమ్ ఈ పంటలను సూచిస్తోంది.`
        : 'నేల పోషక విలువలు ఇవ్వకపోవడం వల్ల సీజన్ / నేల రకం ఆధారంగా సూచనలు ఇవ్వబడ్డాయి.'
    });
  } catch (err) {
    console.error('Error in /api/ml/recommend:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Reverse geocode endpoint for map / GPS selection
app.get('/api/location/reverse', async (req, res) => {
  try {
    const lat = Number(req.query.lat);
    const lon = Number(req.query.lon);
    if (!lat || !lon) {
      return res.status(400).json({ error: 'lat and lon query params required' });
    }
    const data = await reverseGeocode(lat, lon);
    if (!data) {
      return res.status(500).json({ error: 'Reverse geocoding failed' });
    }
    res.json(data);
  } catch (err) {
    console.error('Error in /api/location/reverse:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Profit calculator with editable inputs
app.post('/api/profit', (req, res) => {
  try {
    const {
      crop,
      landSizeAcres,
      yieldPerAcre,
      pricePerQuintal,
      costPerAcre
    } = req.body || {};

    const area = Number(landSizeAcres) || 1;
    const ypa = Number(yieldPerAcre) || 10;
    const ppq = Number(pricePerQuintal) || 2000;
    const cpa = Number(costPerAcre) || 20000;

    const totalYieldQuintals = ypa * area;
    const grossIncome = totalYieldQuintals * ppq;
    const totalCost = cpa * area;
    const netProfit = grossIncome - totalCost;

    res.json({
      crop,
      areaAcres: area,
      yieldPerAcre: ypa,
      totalYieldQuintals,
      pricePerQuintal: ppq,
      grossIncome,
      costPerAcre: cpa,
      totalCost,
      netProfit
    });
  } catch (err) {
    console.error('Error in /api/profit:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ─── Drone Booking API ───────────────────────────────────────────────────────

// In-memory store for drone bookings
const DRONE_BOOKINGS = db.prepare('SELECT payload FROM bookings').all().map(r => JSON.parse(r.payload));

const DRONE_SERVICES = [
  { id: 'pesticide_spray', nameTe: 'పురుగు మందు పిచికారీ', nameEn: 'Pesticide Spray', ratePerAcre: 400, durationMinPerAcre: 10 },
  { id: 'fertilizer_spray', nameTe: 'ఎరువు పిచికారీ', nameEn: 'Fertilizer Spray', ratePerAcre: 350, durationMinPerAcre: 10 },
  { id: 'seeding', nameTe: 'విత్తన చల్లడం', nameEn: 'Aerial Seeding', ratePerAcre: 500, durationMinPerAcre: 15 },
  { id: 'survey', nameTe: 'పొలం సర్వే / మ్యాపింగ్', nameEn: 'Field Survey & Mapping', ratePerAcre: 300, durationMinPerAcre: 8 },
  { id: 'fungicide_spray', nameTe: 'శిలీంధ్ర నాశని పిచికారీ', nameEn: 'Fungicide Spray', ratePerAcre: 400, durationMinPerAcre: 10 }
];

// GET /api/drone/services — list available services with rates
app.get('/api/drone/services', (_req, res) => {
  res.json({ services: DRONE_SERVICES });
});

// POST /api/drone/book — create a booking
app.post('/api/drone/book', async (req, res) => {
  try {
    const {
      farmerName,
      phone,
      district,
      mandal,
      village,
      lat,
      lon,
      landSizeAcres,
      crop,
      serviceType,
      preferredDate,
      preferredTime,
      notes
    } = req.body || {};

    if (!phone) {
      return res.status(400).json({ error: 'phone is required' });
    }
    if (!serviceType) {
      return res.status(400).json({ error: 'serviceType is required' });
    }
    if (!preferredDate) {
      return res.status(400).json({ error: 'preferredDate is required' });
    }

    const service = DRONE_SERVICES.find((s) => s.id === serviceType);
    const acres = Number(landSizeAcres) || 1;
    const estimatedCost = service ? service.ratePerAcre * acres : null;
    const estimatedDurationMin = service ? service.durationMinPerAcre * acres : null;

    const booking = {
      id: `DB-${Date.now()}`,
      farmerName: farmerName || null,
      phone,
      location: {
        district: district || null,
        mandal: mandal || null,
        village: village || null,
        lat: lat ? Number(lat) : null,
        lon: lon ? Number(lon) : null
      },
      landSizeAcres: acres,
      crop: crop || null,
      serviceType,
      serviceName: service ? service.nameTe : serviceType,
      preferredDate,
      preferredTime: preferredTime || null,
      notes: notes || null,
      estimatedCost,
      estimatedDurationMin,
      status: 'pending',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    // If external drone API is configured, forward the request
    const baseUrl = process.env.DRONE_API_BASE_URL;
    const apiKey = process.env.DRONE_API_KEY;

    if (baseUrl && apiKey && !baseUrl.includes('example.com')) {
      try {
        const { data: extData } = await axios.post(
          `${baseUrl}/drones/book`,
          booking,
          { headers: { 'Content-Type': 'application/json', 'X-API-KEY': apiKey } }
        );
        booking.externalRef = extData?.id || extData?.bookingId || null;
        booking.status = extData?.status || 'pending';
      } catch (extErr) {
        console.warn('External drone API call failed, saving locally:', extErr.message);
      }
    }

    const bookingToken = crypto.randomBytes(32).toString('hex');
    db.prepare('INSERT INTO bookings (id,payload,secret_hash) VALUES (?,?,?)').run(booking.id,JSON.stringify(booking),hash(bookingToken));
    DRONE_BOOKINGS.push(booking);

    res.json({
      messageTe: 'డ్రోన్ బుకింగ్ విజయవంతంగా నమోదు అయింది! మీ ఫోన్ నంబరుకు ధృవీకరణ వస్తుంది.',
      booking, bookingToken
    });
  } catch (err) {
    console.error('Error in /api/drone/book:', err.message);
    res.status(500).json({ error: 'Drone booking failed' });
  }
});

// GET /api/drone/bookings — list bookings (optionally filter by phone)
app.get('/api/drone/bookings', adminOnly, (req, res) => {
  const { phone, status } = req.query;
  let list = [...DRONE_BOOKINGS].sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
  if (phone) list = list.filter((b) => b.phone === String(phone));
  if (status) list = list.filter((b) => b.status === String(status));
  res.json({ total: list.length, bookings: list });
});

// GET /api/drone/bookings/:id — get a single booking
app.get('/api/drone/bookings/:id', (req, res) => {
  const booking = DRONE_BOOKINGS.find((b) => b.id === req.params.id);
  if (!booking) return res.status(404).json({ error: 'Booking not found' });
  if (!ownerOrAdmin(req,booking)) return res.status(403).json({error:'Booking authorization required'});
  res.json({ booking });
});

// PATCH /api/drone/bookings/:id/cancel — cancel a booking
app.patch('/api/drone/bookings/:id/cancel', (req, res) => {
  const booking = DRONE_BOOKINGS.find((b) => b.id === req.params.id);
  if (!booking) return res.status(404).json({ error: 'Booking not found' });
  if (!ownerOrAdmin(req,booking)) return res.status(403).json({error:'Booking authorization required'});
  if (booking.status === 'completed') {
    return res.status(400).json({ error: 'Cannot cancel a completed booking' });
  }
  booking.status = 'cancelled';
  booking.updatedAt = new Date().toISOString();
  saveBooking(booking);
  res.json({
    messageTe: 'మీ బుకింగ్ రద్దు అయింది.',
    booking
  });
});

// PATCH /api/drone/bookings/:id/status — update status (for operators/admin)
app.patch('/api/drone/bookings/:id/status', adminOnly, (req, res) => {
  const { status } = req.body || {};
  const allowed = ['pending', 'confirmed', 'in_progress', 'completed', 'cancelled'];
  if (!allowed.includes(status)) {
    return res.status(400).json({ error: `status must be one of: ${allowed.join(', ')}` });
  }
  const booking = DRONE_BOOKINGS.find((b) => b.id === req.params.id);
  if (!booking) return res.status(404).json({ error: 'Booking not found' });
  booking.status = status;
  booking.updatedAt = new Date().toISOString();
  saveBooking(booking);
  res.json({ messageTe: 'బుకింగ్ స్టేటస్ అప్‌డేట్ అయింది.', booking });
});

// Ads endpoint
app.get('/api/ads', (_req, res) => {
  res.json({ ads: ADS });
});

// Discussion: list posts
app.get('/api/discussions', (req, res) => {
  const limit = Math.min(Number(req.query.limit) || 20, 100);
  const posts = [...DISCUSSION_POSTS]
    .sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1))
    .slice(0, limit)
    .map((p) => ({
      ...p,
      commentCount: DISCUSSION_COMMENTS.filter((c) => c.postId === p.id).length
    }));
  res.json({ posts });
});

// Discussion: create post
app.post('/api/discussions', (req, res) => {
  const { name, phone, district, mandal, village, titleTe, problemTe } = req.body || {};
  if (!problemTe) {
    return res.status(400).json({ error: 'problemTe is required' });
  }

  const post = {
    id: `DP-${Date.now()}`,
    name: name || null,
    phone: phone || null,
    location: { district: district || null, mandal: mandal || null, village: village || null },
    titleTe: titleTe || null,
    problemTe,
    createdAt: new Date().toISOString()
  };

  DISCUSSION_POSTS.push(post);
  res.json({
    messageTe: 'మీ సమస్య పోస్ట్ అయింది. ఇతర రైతులు స్పందిస్తారు.',
    post
  });
});

// Discussion: list comments for a post
app.get('/api/discussions/:postId/comments', (req, res) => {
  const { postId } = req.params;
  const comments = DISCUSSION_COMMENTS.filter((c) => c.postId === postId).sort((a, b) =>
    a.createdAt < b.createdAt ? -1 : 1
  );
  res.json({ comments });
});

// Discussion: add comment
app.post('/api/discussions/:postId/comments', (req, res) => {
  const { postId } = req.params;
  const { name, phone, replyTe } = req.body || {};
  if (!replyTe) {
    return res.status(400).json({ error: 'replyTe is required' });
  }

  const exists = DISCUSSION_POSTS.some((p) => p.id === postId);
  if (!exists) {
    return res.status(404).json({ error: 'Post not found' });
  }

  const comment = {
    id: `DC-${Date.now()}`,
    postId,
    name: name || null,
    phone: phone || null,
    replyTe,
    createdAt: new Date().toISOString()
  };

  DISCUSSION_COMMENTS.push(comment);
  res.json({
    messageTe: 'మీ సమాధానం నమోదు అయింది.',
    comment
  });
});

// Branding / advertising request endpoint
app.post('/api/ads/request', (req, res) => {
  const {
    brandName,
    contactName,
    phone,
    district,
    mandal,
    village,
    productTitleTe,
    descriptionTe,
    ctaUrl,
    budget,
    notes
  } = req.body || {};

  if (!brandName || !phone) {
    return res.status(400).json({ error: 'brandName and phone are required' });
  }

  const request = {
    id: `AR-${Date.now()}`,
    brandName,
    contactName: contactName || null,
    phone,
    targeting: { district: district || null, mandal: mandal || null, village: village || null },
    productTitleTe: productTitleTe || null,
    descriptionTe: descriptionTe || null,
    ctaUrl: ctaUrl || null,
    budget: budget || null,
    notes: notes || null,
    createdAt: new Date().toISOString(),
    status: 'received'
  };

  AD_REQUESTS.push(request);
  res.json({
    messageTe:
      'మీ బ్రాండింగ్ / ప్రకటన అభ్యర్థన నమోదు అయింది. త్వరలో మా టీమ్ మీకు కాల్ చేస్తుంది.',
    request
  });
});

// Worker request: submit
app.post('/api/workers/request', (req, res) => {
  const {
    farmerName,
    phone,
    district,
    mandal,
    village,
    workType,
    workersNeeded,
    landSizeAcres,
    preferredDate,
    notes
  } = req.body || {};

  if (!phone || !workType) {
    return res.status(400).json({ error: 'phone and workType are required' });
  }

  const request = {
    id: `WR-${Date.now()}`,
    farmerName: farmerName || null,
    phone,
    location: { district: district || null, mandal: mandal || null, village: village || null },
    workType,
    workersNeeded: Number(workersNeeded) || 1,
    landSizeAcres: Number(landSizeAcres) || null,
    preferredDate: preferredDate || null,
    notes: notes || null,
    createdAt: new Date().toISOString(),
    status: 'open'
  };

  WORKER_REQUESTS.push(request);
  res.json({
    messageTe:
      'మీ కూలీల అభ్యర్థన నమోదు అయింది. అందుబాటులో ఉన్న కూలీలకు సమాచారం పంపుతాం.',
    request
  });
});

// Worker request: list
app.get('/api/workers/requests', (req, res) => {
  const limit = Math.min(Number(req.query.limit) || 20, 100);
  const requests = [...WORKER_REQUESTS]
    .sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1))
    .slice(0, limit);
  res.json({ requests });
});

// Aanadatha-style content endpoint
app.get('/api/content', (req, res) => {
  const { category } = req.query;
  const filtered = category
    ? CONTENT_ITEMS.filter((item) => item.category === String(category))
    : CONTENT_ITEMS;

  res.json({ items: filtered });
});

// ═══════════════════════════════════════════════════════════════
//  MARKET RATES  (Agmarknet / data.gov.in)
// ═══════════════════════════════════════════════════════════════

function todayStr() {
  const d = new Date();
  return `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}/${d.getFullYear()}`;
}

const MANDI_FALLBACK = [
  { commodity:'వరి / Paddy', variety:'BPT 5204 (Sona Masuri)', market:'గుంటూరు మార్కెట్', district:'Guntur',       state:'Andhra Pradesh', minPrice:2183, maxPrice:2400, modalPrice:2250, unit:'Quintal' },
  { commodity:'వరి / Paddy', variety:'Common',                 market:'కృష్ణా APMC',    district:'Krishna',       state:'Andhra Pradesh', minPrice:2050, maxPrice:2183, modalPrice:2183, unit:'Quintal' },
  { commodity:'వరి / Paddy', variety:'IR-64',                  market:'నెల్లూరు మండి',  district:'SPSR Nellore',  state:'Andhra Pradesh', minPrice:2000, maxPrice:2183, modalPrice:2150, unit:'Quintal' },
  { commodity:'వరి / Paddy', variety:'Common',                 market:'వరంగల్ మార్కెట్',district:'Warangal',      state:'Telangana',       minPrice:2183, maxPrice:2350, modalPrice:2200, unit:'Quintal' },
  { commodity:'వరి / Paddy', variety:'MTU 1010',               market:'కరీంనగర్ APMC',  district:'Karimnagar',    state:'Telangana',       minPrice:2100, maxPrice:2250, modalPrice:2183, unit:'Quintal' },
  { commodity:'మొక్కజొన్న / Maize',  variety:'Yellow',         market:'నిజామాబాద్',     district:'Nizamabad',     state:'Telangana',       minPrice:1760, maxPrice:2200, modalPrice:2000, unit:'Quintal' },
  { commodity:'మొక్కజొన్న / Maize',  variety:'Hybrid',         market:'గుంటూరు మార్కెట్',district:'Guntur',       state:'Andhra Pradesh', minPrice:1700, maxPrice:2100, modalPrice:1900, unit:'Quintal' },
  { commodity:'పత్తి / Cotton',       variety:'Long Staple',    market:'గుంటూరు మార్కెట్',district:'Guntur',       state:'Andhra Pradesh', minPrice:6600, maxPrice:7500, modalPrice:7200, unit:'Quintal' },
  { commodity:'పత్తి / Cotton',       variety:'Medium Staple',  market:'ఆదిలాబాద్',      district:'Adilabad',      state:'Telangana',       minPrice:6000, maxPrice:7000, modalPrice:6600, unit:'Quintal' },
  { commodity:'మిర్చి / Chilli',      variety:'Teja S17',       market:'గుంటూరు మార్కెట్',district:'Guntur',       state:'Andhra Pradesh', minPrice:15000,maxPrice:25000,modalPrice:20000,unit:'Quintal' },
  { commodity:'మిర్చి / Chilli',      variety:'LCA 334',        market:'వరంగల్ మార్కెట్',district:'Warangal',      state:'Telangana',       minPrice:12000,maxPrice:22000,modalPrice:17000,unit:'Quintal' },
  { commodity:'పసుపు / Turmeric',     variety:'Erode',          market:'నిజామాబాద్',     district:'Nizamabad',     state:'Telangana',       minPrice:9500, maxPrice:14000,modalPrice:12000,unit:'Quintal' },
  { commodity:'శనగ / Chickpea',       variety:'Desi',           market:'కర్నూలు మండి',  district:'Kurnool',       state:'Andhra Pradesh', minPrice:5200, maxPrice:5800, modalPrice:5440, unit:'Quintal' },
  { commodity:'సోయాబీన్ / Soybean',   variety:'Yellow',         market:'వరంగల్',         district:'Warangal',      state:'Telangana',       minPrice:4050, maxPrice:4800, modalPrice:4600, unit:'Quintal' },
  { commodity:'వేరుశనగ / Groundnut',  variety:'Bold',           market:'కర్నూలు మండి',  district:'Kurnool',       state:'Andhra Pradesh', minPrice:5000, maxPrice:6000, modalPrice:5500, unit:'Quintal' },
  { commodity:'ఉల్లి / Onion',        variety:'Red',            market:'కర్నూలు మండి',  district:'Kurnool',       state:'Andhra Pradesh', minPrice:1200, maxPrice:2800, modalPrice:2000, unit:'Quintal' },
  { commodity:'టమాటా / Tomato',       variety:'Hybrid',         market:'మదనపల్లి మండి', district:'Chittoor',      state:'Andhra Pradesh', minPrice:500,  maxPrice:2000, modalPrice:1200, unit:'Quintal' },
  { commodity:'బెండకాయ / Bhindi',     variety:'Common',         market:'వికారాబాద్',     district:'Vikarabad',     state:'Telangana',       minPrice:1000, maxPrice:2500, modalPrice:1800, unit:'Quintal' },
  { commodity:'పెసర / Moong',         variety:'Green',          market:'నల్లగొండ',       district:'Nalgonda',      state:'Telangana',       minPrice:7000, maxPrice:8000, modalPrice:7500, unit:'Quintal' },
  { commodity:'మినుము / Urad',        variety:'Black',          market:'కృష్ణా APMC',    district:'Krishna',       state:'Andhra Pradesh', minPrice:6000, maxPrice:7000, modalPrice:6600, unit:'Quintal' },
  { commodity:'జొన్న / Jowar',        variety:'White',          market:'మహబూబ్‌నగర్',   district:'Mahbubnagar',   state:'Telangana',       minPrice:2750, maxPrice:3200, modalPrice:2950, unit:'Quintal' },
  { commodity:'జొన్న / Jowar',        variety:'Red',            market:'కర్నూలు మండి',  district:'Kurnool',       state:'Andhra Pradesh', minPrice:2500, maxPrice:3000, modalPrice:2800, unit:'Quintal' },
  { commodity:'సజ్జ / Bajra',         variety:'Common',         market:'అనంతపురం',       district:'Anantapur',     state:'Andhra Pradesh', minPrice:2200, maxPrice:2600, modalPrice:2350, unit:'Quintal' },
  { commodity:'నువ్వులు / Sesame',    variety:'White',          market:'ప్రకాశం',        district:'Prakasam',      state:'Andhra Pradesh', minPrice:12000,maxPrice:15000,modalPrice:13500,unit:'Quintal' },
  { commodity:'ఆముదం / Castor',       variety:'Common',         market:'ఆదిలాబాద్',      district:'Adilabad',      state:'Telangana',       minPrice:5000, maxPrice:6500, modalPrice:5800, unit:'Quintal' },
  { commodity:'అరటి / Banana',        variety:'Robusta',        market:'కడప మండి',       district:'Kadapa',        state:'Andhra Pradesh', minPrice:800,  maxPrice:1800, modalPrice:1400, unit:'Quintal' },
  { commodity:'అరటి / Banana',        variety:'Red',            market:'హైదరాబాద్ మండి', district:'Hyderabad',     state:'Telangana',       minPrice:1000, maxPrice:2200, modalPrice:1600, unit:'Quintal' },
  { commodity:'మామిడి / Mango',       variety:'Banginapalli',   market:'చిత్తూరు APMC',  district:'Chittoor',      state:'Andhra Pradesh', minPrice:2000, maxPrice:5000, modalPrice:3500, unit:'Quintal' },
];

const MSP_2024 = {
  'వరి / Paddy': 2183, 'మొక్కజొన్న / Maize': 1760, 'పత్తి / Cotton': 6620,
  'శనగ / Chickpea': 5440, 'సోయాబీన్ / Soybean': 4600, 'వేరుశనగ / Groundnut': 6377,
  'జొన్న / Jowar': 3180, 'సజ్జ / Bajra': 2500, 'నువ్వులు / Sesame': 9267
};

app.get('/api/market-rates', async (req, res) => {
  const { state, commodity, limit = 30 } = req.query;
  const apiKey = process.env.AGMARKNET_API_KEY;
  const date = todayStr();

  if (apiKey && apiKey !== 'your_agmarknet_api_key_here') {
    try {
      const params = { 'api-key': apiKey, format: 'json', limit, 'filters[state.keyword]': state || 'Andhra Pradesh' };
      if (commodity) params['filters[commodity]'] = commodity;
      const { data } = await axios.get(
        'https://api.data.gov.in/resource/9ef84268-d588-465a-a308-a864a43d0070',
        { params, timeout: 8000 }
      );
      return res.json({ success: true, live: true, date, records: data.records || [] });
    } catch (e) {
      console.error('Agmarknet API error:', e.message);
    }
  }

  let records = [...MANDI_FALLBACK].map(r => ({ ...r, date }));
  if (state) {
    const q = state.toLowerCase();
    records = records.filter(r => r.state.toLowerCase().includes(q) || r.district.toLowerCase().includes(q));
  }
  if (commodity) {
    const q = commodity.toLowerCase();
    records = records.filter(r => r.commodity.toLowerCase().includes(q));
  }
  records = records.slice(0, Number(limit));
  res.json({ success: true, live: false, fallback: true, date, msp: MSP_2024, records });
});

// ═══════════════════════════════════════════════════════════════
//  NEAREST MARKET YARDS  (Haversine + comprehensive AP/Telangana list)
// ═══════════════════════════════════════════════════════════════

const TELUGU_MANDIS = [
  { name:'గుంటూరు APMC మార్కెట్',       district:'Guntur',         state:'AP',  lat:16.3067, lng:80.4365, commodities:['Chilli','Paddy','Cotton','Turmeric'] },
  { name:'కృష్ణా జిల్లా మార్కెట్',      district:'Krishna',        state:'AP',  lat:16.5193, lng:80.6305, commodities:['Paddy','Maize','Vegetables'] },
  { name:'నెల్లూరు మార్కెట్ యార్డ్',    district:'SPSR Nellore',   state:'AP',  lat:14.4426, lng:79.9865, commodities:['Paddy','Aqua','Tomato'] },
  { name:'కర్నూలు APMC',                 district:'Kurnool',        state:'AP',  lat:15.8281, lng:78.0373, commodities:['Groundnut','Onion','Jowar','Chickpea'] },
  { name:'అనంతపురం మార్కెట్',            district:'Anantapur',      state:'AP',  lat:14.6819, lng:77.6006, commodities:['Groundnut','Tomato','Onion'] },
  { name:'చిత్తూరు APMC',                district:'Chittoor',       state:'AP',  lat:13.2172, lng:79.1003, commodities:['Mango','Tomato','Paddy'] },
  { name:'మదనపల్లి మార్కెట్',            district:'Chittoor',       state:'AP',  lat:13.5530, lng:78.5010, commodities:['Tomato','Potato','Onion'] },
  { name:'కడప APMC',                     district:'YSR Kadapa',     state:'AP',  lat:14.4673, lng:78.8242, commodities:['Paddy','Groundnut','Jowar'] },
  { name:'విజయవాడ APMC',                 district:'Krishna',        state:'AP',  lat:16.5062, lng:80.6480, commodities:['Paddy','Vegetables','Fruits'] },
  { name:'రాజమండ్రి మార్కెట్ యార్డ్',   district:'East Godavari',  state:'AP',  lat:16.9891, lng:81.7840, commodities:['Paddy','Banana','Coconut'] },
  { name:'ఒంగోలు మార్కెట్',              district:'Prakasam',       state:'AP',  lat:15.5057, lng:80.0499, commodities:['Paddy','Sesame','Chilli'] },
  { name:'తిరుపతి APMC',                 district:'Tirupati',       state:'AP',  lat:13.6288, lng:79.4192, commodities:['Paddy','Vegetables','Fruits'] },
  { name:'విశాఖపట్నం మార్కెట్',          district:'Visakhapatnam',  state:'AP',  lat:17.6868, lng:83.2185, commodities:['Paddy','Fish','Fruits'] },
  { name:'శ్రీకాకుళం APMC',              district:'Srikakulam',     state:'AP',  lat:18.2949, lng:83.8938, commodities:['Paddy','Cashew','Coconut'] },
  { name:'హైదరాబాద్ గడ్డి అన్నారం',      district:'Hyderabad',      state:'TS',  lat:17.4250, lng:78.4740, commodities:['Paddy','Maize','Jowar','Vegetables'] },
  { name:'వరంగల్ APMC మార్కెట్',         district:'Warangal',       state:'TS',  lat:17.9784, lng:79.5941, commodities:['Paddy','Cotton','Maize','Chilli'] },
  { name:'కరీంనగర్ మార్కెట్ యార్డ్',     district:'Karimnagar',     state:'TS',  lat:18.4386, lng:79.1288, commodities:['Paddy','Turmeric','Maize'] },
  { name:'నిజామాబాద్ APMC',              district:'Nizamabad',      state:'TS',  lat:18.6725, lng:78.0941, commodities:['Maize','Turmeric','Paddy','Soybean'] },
  { name:'మహబూబ్‌నగర్ మార్కెట్',        district:'Mahbubnagar',    state:'TS',  lat:16.7381, lng:77.9863, commodities:['Paddy','Jowar','Cotton'] },
  { name:'నల్లగొండ APMC',                district:'Nalgonda',       state:'TS',  lat:17.0579, lng:79.2677, commodities:['Paddy','Moong','Cotton'] },
  { name:'సిద్ధిపేట మార్కెట్',           district:'Siddipet',       state:'TS',  lat:18.1014, lng:78.8521, commodities:['Paddy','Maize','Vegetables'] },
  { name:'ఆదిలాబాద్ APMC',               district:'Adilabad',       state:'TS',  lat:19.6636, lng:78.5320, commodities:['Cotton','Soybean','Castor'] },
  { name:'ఖమ్మం మార్కెట్ యార్డ్',        district:'Khammam',        state:'TS',  lat:17.2473, lng:80.1514, commodities:['Paddy','Cotton','Chilli'] },
  { name:'రంగారెడ్డి APMC',               district:'Rangareddy',     state:'TS',  lat:17.2980, lng:78.3510, commodities:['Vegetables','Fruits','Flowers'] },
  { name:'సంగారెడ్డి మార్కెట్',           district:'Sangareddy',     state:'TS',  lat:17.6258, lng:77.9983, commodities:['Cotton','Maize','Paddy'] },
  { name:'వికారాబాద్ మార్కెట్',           district:'Vikarabad',      state:'TS',  lat:17.3388, lng:77.9022, commodities:['Paddy','Vegetables','Maize'] },
  { name:'జగిత్యాల APMC',                district:'Jagitial',       state:'TS',  lat:18.7946, lng:78.9162, commodities:['Paddy','Maize','Turmeric'] },
  { name:'భద్రాచలం మార్కెట్',            district:'Bhadradri KT',   state:'TS',  lat:17.6686, lng:80.8942, commodities:['Paddy','Bamboo','Forest produce'] },
  { name:'శ్రీ రాంనగర్ జిల్లా మండి',     district:'Nandyal',        state:'AP',  lat:15.4779, lng:78.4887, commodities:['Groundnut','Onion','Cotton'] },
  { name:'తాడేపల్లిగూడెం మార్కెట్',      district:'West Godavari',  state:'AP',  lat:16.8130, lng:81.5222, commodities:['Paddy','Coconut','Banana'] },
];

function haversineKm(lat1, lng1, lat2, lng2) {
  const R = 6371;
  const toRad = x => x * Math.PI / 180;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a = Math.sin(dLat/2)**2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
}

app.get('/api/nearest-mandis', (req, res) => {
  const { lat, lng, limit = 8 } = req.query;
  if (!lat || !lng) return res.status(400).json({ error: 'lat మరియు lng అవసరం' });
  const userLat = parseFloat(lat);
  const userLng = parseFloat(lng);
  if (isNaN(userLat) || isNaN(userLng)) return res.status(400).json({ error: 'సరైన GPS కోఆర్డినేట్లు ఇవ్వండి' });

  const sorted = TELUGU_MANDIS
    .map(m => ({ ...m, distanceKm: Math.round(haversineKm(userLat, userLng, m.lat, m.lng)) }))
    .sort((a, b) => a.distanceKm - b.distanceKm)
    .slice(0, Number(limit));
  res.json({ success: true, mandis: sorted });
});

// ═══════════════════════════════════════════════════════════════
//  TELUGU AI ASSISTANT  (Bhashini TTS + knowledge base)
// ═══════════════════════════════════════════════════════════════

// Telugu Unicode range: \u0C00-\u0C7F
// Word-boundary matching: key must NOT be preceded or followed by another Telugu character
function teluguWordMatch(text, key) {
  const escaped = key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const re = new RegExp('(^|[^\\u0C00-\\u0C7F])' + escaped + '($|[^\\u0C00-\\u0C7F])', 'iu');
  return re.test(text);
}

const AGRI_KB = [
  // ── Greetings & meta (MUST be first to avoid substring conflicts) ──
  { keys:['నమస్కారం','నమస్తే','హలో','hello','hi','ఎవరు','ఏమి చేస్తారు','ఏమి అడగాలి'], response:`🙏 నమస్కారం! నేను తెలుగు రైతు AI సహాయకుడిని.\n\nనేను మీకు ఇవి సహాయపడతాను:\n✅ పంట సమాచారం (వరి, మిర్చి, పత్తి, మొక్కజొన్న...)\n✅ మార్కెట్ ధరలు & MSP సమాచారం\n✅ ఎరువులు & పురుగు నిర్వహణ\n✅ ప్రభుత్వ పథకాలు\n✅ వాతావరణ వ్యవసాయ సూచనలు\n✅ నేల నిర్వహణ\n\nమీ పంట/సమస్య పేరు తెలుగులో లేదా ఇంగ్లీష్‌లో టైప్ చేయండి!` },
  { keys:['ధన్యవాదాలు','thanks','thank you'], response:`😊 ధన్యవాదాలు! మీకు ఇంకా ఏదైనా సహాయం అవసరమైతే అడగండి.\n🌾 మీ పొలం సమృద్ధిగా ఉండాలని ఆశిస్తున్నాం!` },
  // ── Crops ──
  { keys:['వరి','paddy','rice','ధాన్యం'], response:`🌾 వరి పంట సమాచారం:\n• MSP ధర: ₹2,183/క్వింటాల్ (2024-25)\n• విత్తన రకాలు: BPT 5204 (సోనా మసూరి), MTU 1010, IR-64\n• నాట్ల సమయం: ఖరీఫ్ - జూన్/జూలై; రబీ - నవంబర్/డిసెంబర్\n• ఎరువులు (ఎకరాకు): 50 కిలోల N, 25 కిలోల P, 25 కిలోల K\n• నీటి అవసరం: 1200–1800 మి.మీ\n• దిగుబడి: 25–35 బస్తాలు/ఎకరం\n• ముఖ్య పురుగులు: కాండం తొలుచు పురుగు, చిరుపురుగు` },
  { keys:['మిర్చి','chilli','pepper','మిరప'], response:`🌶 మిర్చి పంట సమాచారం:\n• గుంటూరు మార్కెట్ ధర: ₹15,000–25,000/క్వింటాల్\n• రకాలు: Teja S17, LCA 334, Byadagi\n• నాట్ల సమయం: జూన్–జూలై (ఖరీఫ్), సెప్టెంబర్–అక్టోబర్ (రబీ)\n• ఎరువులు (ఎకరాకు): 40 కిలోల N, 30 కిలోల P, 30 కిలోల K\n• నీటి అవసరం: 600–900 మి.మీ\n• దిగుబడి: 15–25 క్వింటాళ్ళు/ఎకరం\n• జాగ్రత్తలు: తెల్ల ఈగ, నత్తగొట్టు వ్యాధి నివారణ అవసరం` },
  { keys:['పత్తి','cotton'], response:`🌿 పత్తి పంట సమాచారం:\n• MSP ధర: ₹6,620/క్వింటాల్ (2024-25)\n• రకాలు: Bt Cotton హైబ్రిడ్ - RCH 2, Bunny, Jackpot\n• విత్తన సమయం: మే–జూన్\n• ఎరువులు (ఎకరాకు): 60 కిలోల N, 30 కిలోల P, 30 కిలోల K\n• నీటి అవసరం: 700–1000 మి.మీ\n• దిగుబడి: 8–15 క్వింటాళ్ళు/ఎకరం\n• తెగులు: గులాబీ పురుగు (Pink Bollworm) జాగ్రత్త` },
  { keys:['మొక్కజొన్న','maize','corn'], response:`🌽 మొక్కజొన్న సమాచారం:\n• MSP ధర: ₹1,760/క్వింటాల్\n• మార్కెట్ ధర: ₹1,800–2,200/క్వింటాల్\n• విత్తన సమయం: జూన్–జూలై (వర్షాకాలం), జనవరి–ఫిబ్రవరి (రబీ)\n• ఎరువులు: 80 కిలోల N, 40 కిలోల P, 40 కిలోల K (ఎకరాకు)\n• దిగుబడి: 25–35 క్వింటాళ్ళు/ఎకరం\n• ముఖ్యం: Fall Armyworm పురుగు నివారణకు Coragen పిచికారీ` },
  { keys:['పసుపు','turmeric'], response:`💛 పసుపు పంట సమాచారం:\n• నిజామాబాద్ మార్కెట్ ధర: ₹9,500–14,000/క్వింటాల్\n• రకాలు: Rajendra Sonia, NTC-3, Suvarnaprabha\n• నాట్ల సమయం: మే–జూన్\n• కాలం: 8–10 నెలలు\n• ఎరువులు: 60 కిలోల N, 30 కిలోల P (ఎకరాకు)\n• దిగుబడి: 15–25 టన్నులు/ఎకరం (పచ్చి), 3–5 టన్నులు ఎండిన\n• వ్యాధి: Leaf blotch, Rhizome rot జాగ్రత్త` },
  { keys:['వేరుశనగ','groundnut','peanut'], response:`🥜 వేరుశనగ సమాచారం:\n• MSP ధర: ₹6,377/క్వింటాల్\n• కర్నూలు మార్కెట్: ₹5,000–6,000/క్వింటాల్\n• రకాలు: K-6, TAG-24, JL-24, Kadiri-7\n• విత్తన సమయం: జూన్–జూలై (వర్షాకాలం)\n• ఎరువులు: 20N:40P:40K (ఎకరాకు) + జిప్సం 100 కిలోలు\n• దిగుబడి: 8–12 క్వింటాళ్ళు/ఎకరం` },
  { keys:['టమాటా','tomato'], response:`🍅 టమాటా సమాచారం:\n• మదనపల్లి మార్కెట్ ధర: ₹500–2,000/క్వింటాల్ (సీజన్ ప్రకారం)\n• రకాలు: Arka Rakshak, NS 585, US 440\n• నాట్ల సమయం: ఏడాది పొడవునా (నీటి సౌకర్యం ఉంటే)\n• ఎరువులు: 80N:60P:80K (ఎకరాకు)\n• దిగుబడి: 20–40 టన్నులు/ఎకరం\n• జాగ్రత్త: తెల్ల ఈగ, ఆకు మురుగు వ్యాధి నివారణ` },
  { keys:['ఉల్లి','onion','ఉల్లిపాయ'], response:`🧅 ఉల్లి సమాచారం:\n• కర్నూలు మార్కెట్ ధర: ₹1,200–2,800/క్వింటాల్\n• రకాలు: Bellary Red, N-53, Agrifound Light Red\n• నాట్ల సమయం: అక్టోబర్–నవంబర్ (రబీ)\n• ఎరువులు: 100N:50P:50K (ఎకరాకు)\n• దిగుబడి: 80–120 క్వింటాళ్ళు/ఎకరం\n• నిల్వ: సరైన గాలి వ్యవస్థ ఉన్న గోదాంలో 2–3 నెలలు` },
  { keys:['శనగ','chickpea','చెక్కుడు'], response:`🌱 శనగ సమాచారం:\n• MSP ధర: ₹5,440/క్వింటాల్\n• విత్తన సమయం: అక్టోబర్–నవంబర్ (రబీ)\n• నేల: బంక నేల అనుకూలం\n• ఎరువులు: 20N:40P:20K (ఎకరాకు)\n• దిగుబడి: 6–10 క్వింటాళ్ళు/ఎకరం\n• వ్యాధి: ఆకు తొలచే పురుగు, కాండం కుళ్ళు జాగ్రత్త` },
  { keys:['అరటి','banana'], response:`🍌 అరటి సమాచారం:\n• కడప మార్కెట్ ధర: ₹800–1,800/క్వింటాల్\n• రకాలు: Robusta, Grand Naine, Red Banana\n• నాట్ల సమయం: జూన్–సెప్టెంబర్\n• కాలం: 10–12 నెలలు\n• ఎరువులు: 200N:60P:300K (ఒక మొక్కకు గ్రాంలలో)\n• దిగుబడి: 15–25 టన్నులు/ఎకరం` },
  { keys:['జొన్న','jowar','sorghum'], response:`🌾 జొన్న సమాచారం:\n• MSP ధర: ₹3,180/క్వింటాల్\n• విత్తన సమయం: జూన్–జూలై\n• ఎరువులు: 60N:30P:30K (ఎకరాకు)\n• దిగుబడి: 10–20 క్వింటాళ్ళు/ఎకరం\n• తక్కువ నీటి పంట — వర్షాధారంగా పెరుగుతుంది` },
  // ── Farm management ──
  { keys:['వాతావరణం','weather','వర్షం','రుతువు','సీజన్'], response:`⛅ వ్యవసాయ వాతావరణ సమాచారం:\n• ఖరీఫ్ (జూన్–నవంబర్): వర్షాధార పంటలు - వరి, పత్తి, మిర్చి\n• రబీ (నవంబర్–మార్చి): నీటి పారుదల పంటలు - శనగ, పెసర\n• జాయద్ (మార్చి–జూన్): అల్ప కాలిక పంటలు - దోసకాయ, కాకర\n• ముఖ్యం: వేసవిలో తక్కువ నీటి పంటలే వేయాలి\n• ముంపు జాగ్రత్తలు: 48 గంటల ముందే పొలం ఖాళీ చేయాలి` },
  { keys:['ఎరువు','fertilizer','పోషకాలు','NPK','నత్రజని','DAP','యూరియా'], response:`🧪 ఎరువుల సమాచారం:\n• నత్రజని (N): మొక్క ఎదుగుదలకు - యూరియా రూపంలో\n• భాస్వరం (P): వేరు వ్యవస్థకు - DAP రూపంలో\n• పొటాష్ (K): రోగ నిరోధకతకు - MOP రూపంలో\n• జింక్ సల్ఫేట్: మట్టి పరీక్ష తర్వాత అవసరమైతే వాడాలి\n• సేంద్రియ ఎరువు: ఎకరాకు 3–5 టన్నులు పశు ఎరువు వేయాలి\n• జాగ్రత్త: మట్టి పరీక్ష తర్వాతే ఎరువులు వేయండి` },
  { keys:['పురుగు','pest','కీటకం','insect','తెగులు','వ్యాధి'], response:`🐛 పురుగు నిర్వహణ:\n• సమగ్ర పురుగు నిర్వహణ (IPM) అనుసరించండి\n• జీవ నియంత్రణ: Trichogramma కార్డులు వాడండి\n• ఆకర్షణ బోనులు (Pheromone traps): ఎకరాకు 5 పెట్టాలి\n• రసాయన మందులు: చివరి ప్రత్యామ్నాయంగా వాడండి\n• కాండం తొలుచు పురుగు: Chlorpyriphos 20 EC\n• గులాబీ పురుగు: Coragen 18.5% SC\n• తెల్ల ఈగ: Imidacloprid 70 WG` },
  { keys:['నేల','soil','మట్టి','pH','నేల పరీక్ష'], response:`🌱 నేల నిర్వహణ:\n• మట్టి పరీక్ష: 3 సంవత్సరాలకొకసారి తప్పనిసరి\n• pH 6.5–7.5: అన్ని పంటలకూ అనుకూలం\n• pH < 6: సున్నం వేయాలి (ఎకరాకు 200–400 కిలోలు)\n• pH > 7.5: జిప్సం వేయాలి\n• నేల పరీక్ష కేంద్రాలు: జిల్లా వ్యవసాయ కార్యాలయంలో ₹5 కే\n• సేంద్రియ కర్బనం: 0.8% పైన ఉండాలి` },
  { keys:['నీరు','irrigation','నీటి పారుదల','డ్రిప్','స్ప్రింక్లర్'], response:`💧 నీటి నిర్వహణ:\n• డ్రిప్ ఇరిగేషన్: 40–60% నీటి ఆదా + అధిక దిగుబడి\n• స్ప్రింక్లర్: మొక్కకు సమానంగా నీరు\n• వరి: 1200–1800 మి.మీ నీరు అవసరం\n• మిర్చి: 600–900 మి.మీ అవసరం\n• పత్తి: 700–1000 మి.మీ అవసరం\n• నీటి ఆదాకు PM Krishi Sinchayee Yojana సహాయం పొందండి` },
  // ── Government & services ──
  { keys:['ప్రభుత్వ','scheme','yojana','రైతు బంధు','రైతు భరోసా','కిసాన్','పథకం','సబ్సిడీ'], response:`🏛 ప్రభుత్వ పథకాలు:\n• రైతు భరోసా (AP): ₹13,500/ఎకరం/సంవత్సరానికి\n• రైతు బంధు (TS): ₹10,000/ఎకరం/సీజన్\n• PM-KISAN: ₹6,000/సంవత్సరం (3 వాయిదాలు)\n• ఫసల్ బీమా (PMFBY): 2% ప్రీమియంలో పంట బీమా\n• KCC (Kisan Credit Card): తక్కువ వడ్డీకి రుణం\n• eNAM: ఆన్‌లైన్ మండీలో మీ పంట అమ్మండి\n• హెల్ప్‌లైన్: 1800-180-1551 (ఉచిత)` },
  { keys:['రుణం','loan','credit','బ్యాంక్','వడ్డీ'], response:`💰 వ్యవసాయ రుణాలు:\n• KCC (Kisan Credit Card): 7% వడ్డీ, ₹3 లక్షల వరకు\n• PM Fasal Bima: తక్కువ ప్రీమియంలో పంట బీమా\n• SHG రుణాలు: మహిళా రైతులకు 4% వడ్డీ\n• NABARD రుణాలు: గ్రామీణ అభివృద్ధికి\n• దరఖాస్తు: సమీప గ్రామీణ బ్యాంక్ లేదా PACS సంప్రదించండి` },
  { keys:['డ్రోన్','drone'], response:`🚁 డ్రోన్ సేవలు:\n• పురుగు మందు పిచికారీ: ₹400/ఎకరం\n• ఎరువు పిచికారీ: ₹350/ఎకరం\n• విత్తన చల్లడం: ₹500/ఎకరం\n• పొలం సర్వే: ₹300/ఎకరం\n• ప్రయోజనాలు: 10x వేగం, సమాన పిచికారీ, కూలీ ఖర్చు తగ్గింపు\n• బుకింగ్: డ్రోన్ బుకింగ్ ట్యాబ్ లో నమోదు చేయండి` },
  { keys:['కూలీ','worker','labour'], response:`👨‍🌾 కూలీ సమాచారం:\n• కూలీ ధర (AP/TS): పురుషులు ₹350–500/రోజు, మహిళలు ₹280–400/రోజు\n• MGNREGS: 100 రోజుల హామీ ఉద్యోగం, ₹267/రోజు\n• యంత్ర కూలీ: ట్రాక్టర్ ₹600–800/గంట\n• హార్వెస్టర్: ₹2,000–3,000/ఎకరం\n• కూలీ అభ్యర్థన: కూలీల ట్యాబ్ ఉపయోగించండి` },
  { keys:['మండి','market','మార్కెట్','ధర','price','rate','ధరలు'], response:`📊 మార్కెట్ ధరలు (2024-25):\n• వరి: ₹2,050–2,400/క్వింటాల్\n• మిర్చి: ₹15,000–25,000/క్వింటాల్\n• పత్తి: ₹6,000–7,500/క్వింటాల్\n• మొక్కజొన్న: ₹1,760–2,200/క్వింటాల్\n• పసుపు: ₹9,500–14,000/క్వింటాల్\n• వేరుశనగ: ₹5,000–6,377/క్వింటాల్\n• ఉల్లి: ₹1,200–2,800/క్వింటాల్\n📌 "మార్కెట్ ధరలు" ట్యాబ్ లో నేటి ధరలు చూడండి` },
];

// Word-boundary aware AI matching — prevents "కారం" matching inside "నమస్కారం" etc.
function findAgriResponse(msg) {
  const text = msg.trim();
  const lower = text.toLowerCase();
  for (const item of AGRI_KB) {
    if (item.keys.some(k => teluguWordMatch(lower, k.toLowerCase()))) {
      return item.response;
    }
  }
  return null;
}

// Server-side farmer profile store (phone → profile)
const FARMER_PROFILES = new Map();

async function bhashiniTTS(text) {
  const apiKey = process.env.BHASHINI_API_KEY;
  const userId = process.env.BHASHINI_USER_ID;
  if (!apiKey || apiKey === 'your_bhashini_api_key_here') return null;
  try {
    const pipelineRes = await axios.post(
      'https://meity-auth.ulcacontrib.org/ulca/apis/v0/model/getModelsPipeline',
      { pipelineTasks: [{ taskType: 'tts', config: { language: { sourceLanguage: 'te' } } }], pipelineRequestConfig: { pipelineId: 'ai4bharat/indic-gen-indo-aryan' } },
      { headers: { userID: userId, ulcaApiKey: apiKey }, timeout: 8000 }
    );
    const svcId = pipelineRes.data?.pipelineResponseConfig?.[0]?.config?.[0]?.serviceId;
    const callbackUrl = pipelineRes.data?.pipelineInferenceAPIEndPoint?.callbackUrl;
    const inferKey = pipelineRes.data?.pipelineInferenceAPIEndPoint?.inferenceApiKey?.value;
    if (!svcId || !callbackUrl) return null;
    const infer = await axios.post(callbackUrl, {
      pipelineTasks: [{ taskType: 'tts', config: { language: { sourceLanguage: 'te' }, serviceId: svcId, gender: 'male', samplingRate: 8000 } }],
      inputData: { input: [{ source: text }] }
    }, { headers: { Authorization: inferKey }, timeout: 15000 });
    return infer.data?.pipelineResponse?.[0]?.audio?.[0]?.audioContent || null;
  } catch (e) {
    console.error('Bhashini TTS error:', e.message);
    return null;
  }
}

// ─── English → Telugu translation ───────────────────────────────
const EN_TE_AGRI = {
  // crops
  rice:'వరి', paddy:'వరి', wheat:'గోధుమ', maize:'మొక్కజొన్న', corn:'మొక్కజొన్న',
  cotton:'పత్తి', chilli:'మిర్చి', chili:'మిర్చి', redchilli:'ఎర్ర మిర్చి',
  groundnut:'వేరుశనగ', peanut:'వేరుశనగ', sugarcane:'చెరకు', soybean:'సోయా',
  turmeric:'పసుపు', onion:'ఉల్లి', tomato:'టమాటో', potato:'బంగాళాదుంప',
  brinjal:'వంకాయ', okra:'బెండ', ladyfinger:'బెండ', mango:'మామిడి',
  banana:'అరటి', coconut:'కొబ్బరి', sunflower:'పొద్దుతిరుగుడు',
  jowar:'జొన్న', bajra:'సజ్జ', ragi:'రాగి', toor:'కందులు', moong:'పెసలు',
  bengalgram:'శనగలు', chickpea:'శనగలు', blackgram:'మినుములు',
  // farming inputs
  fertilizer:'ఎరువు', urea:'యూరియా', dap:'డీఏపీ', potash:'పొటాష్',
  pesticide:'పురుగుమందు', insecticide:'కీటక నాశిని', fungicide:'శిలీంధ్ర నాశిని',
  herbicide:'కలుపు నాశిని', weedicide:'కలుపు నాశిని', seed:'విత్తనం',
  seeds:'విత్తనాలు', compost:'కంపోస్ట్', manure:'పశువుల ఎరువు',
  // soil & water
  soil:'నేల', water:'నీరు', irrigation:'నీటిపారుదల', drip:'డ్రిప్ సేద్యం',
  sprinkler:'స్ప్రింక్లర్', borewell:'బోర్వెల్', canal:'కాలువ',
  // weather
  rain:'వర్షం', drought:'కరువు', flood:'వరద', weather:'వాతావరణం',
  temperature:'ఉష్ణోగ్రత', humidity:'తేమ', wind:'గాలి',
  // market
  market:'మార్కెట్', price:'ధర', rate:'రేటు', msp:'కనీస మద్దతు ధర',
  yield:'దిగుబడి', profit:'లాభం', loss:'నష్టం', income:'ఆదాయం',
  // general farming
  crop:'పంట', crops:'పంటలు', farmer:'రైతు', farm:'పొలం', field:'పొలం',
  harvest:'పంట కోత', sowing:'విత్తనం వేయడం', planting:'నాటడం',
  disease:'తెగులు', pest:'పురుగు', blight:'తెగులు', weed:'కలుపు',
  drone:'డ్రోన్', tractor:'ట్రాక్టర్', pump:'పంప్',
  // government
  government:'ప్రభుత్వం', scheme:'పథకం', loan:'రుణం', subsidy:'సబ్సిడీ',
  insurance:'బీమా', kisan:'కిసాన్', pm:'ప్రధానమంత్రి',
  // question words
  what:'ఏమిటి', how:'ఎలా', when:'ఎప్పుడు', where:'ఎక్కడ', why:'ఎందుకు',
  which:'ఏది', who:'ఎవరు', tell:'చెప్పు', give:'ఇవ్వు', help:'సహాయం',
  about:'గురించి', good:'మంచి', best:'అత్యుత్తమ', season:'సీజన్',
  information:'సమాచారం', details:'వివరాలు', problem:'సమస్య',
  solution:'పరిష్కారం', treatment:'చికిత్స', control:'నివారణ'
};

function dictTranslate(text) {
  const words = text.toLowerCase().split(/\s+/);
  const translated = words.map(w => EN_TE_AGRI[w] || w);
  const hitCount = translated.filter((t,i) => t !== words[i]).length;
  // Only use dict result if ALL words are in dict (pure vocabulary query)
  if (hitCount === words.length) return translated.join(' ');
  return null;
}

app.post('/api/translate-en-te', async (req, res) => {
  const { text } = req.body;
  if (!text || !text.trim()) return res.status(400).json({ error: 'text required' });
  const clean = text.trim();

  // 1. Local dictionary (instant)
  const dictResult = dictTranslate(clean);
  if (dictResult) return res.json({ success: true, telugu: dictResult, source: 'dict' });

  // 2. MyMemory free API (no key needed)
  try {
    const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(clean)}&langpair=en|te&de=farmerapp@telugu.ai`;
    const r = await fetch(url, { signal: AbortSignal.timeout(6000) });
    const d = await r.json();
    const result = d.responseData?.translatedText;
    if (result && result !== clean) return res.json({ success: true, telugu: result, source: 'mymemory' });
  } catch {}

  return res.json({ success: true, telugu: clean, source: 'passthrough' });
});

app.post('/api/ai-chat', async (req, res) => {
  const { message, tts = false } = req.body;
  if (!message || !message.trim()) return res.status(400).json({ error: 'message అవసరం' });

  let response = findAgriResponse(message.trim());
  if (!response) {
    response = `🤔 మీ ప్రశ్న అర్థమైంది. కానీ ఈ విషయంపై నాకు నేరుగా సమాచారం లేదు.\n\n💡 దయచేసి మీ జిల్లా వ్యవసాయ అధికారిని సంప్రదించండి లేదా 1800-180-1551 కు ఉచితంగా కాల్ చేయండి.\n\n📌 మీరు ఇవి అడగవచ్చు: వరి, మిర్చి, పత్తి, ఎరువులు, పురుగులు, మార్కెట్ ధరలు, ప్రభుత్వ పథకాలు, నేల, వాతావరణం`;
  }

  let audioBase64 = null;
  if (tts) {
    audioBase64 = await bhashiniTTS(response.replace(/[🌾🌶🌿🌽💛🥜🍅🧅🧪🐛🏛🌱🚁👨‍🌾📊🙏😊⛅🤔💡📌✅]/gu, ''));
  }

  res.json({ success: true, message, response, audioBase64 });
});

// ═══════════════════════════════════════════════════════════════
//  FARMER LOGIN / PROFILE  (phone-based, in-memory + localStorage)
// ═══════════════════════════════════════════════════════════════

app.post('/api/farmer/save', adminOnly, (req, res) => {
  const { name, phone, district, mandal, village, acres, crops, pin } = req.body;
  if (!phone || !name) return res.status(400).json({ error: 'పేరు మరియు ఫోన్ నంబర్ తప్పనిసరి' });
  const cleanPhone = String(phone).replace(/\D/g, '').slice(-10);
  if (cleanPhone.length !== 10) return res.status(400).json({ error: '10 అంకెల ఫోన్ నంబర్ ఇవ్వండి' });
  const profile = {
    name: String(name).trim(),
    phone: cleanPhone,
    district: district || '',
    mandal: mandal || '',
    village: village || '',
    acres: acres || '',
    crops: crops || '',
    pin: pin ? String(pin).replace(/\D/g,'').slice(0,4) : '',
    savedAt: new Date().toISOString()
  };
  delete profile.pin;
  db.prepare('INSERT INTO profiles (phone,payload) VALUES (?,?) ON CONFLICT(phone) DO UPDATE SET payload=excluded.payload').run(cleanPhone,JSON.stringify(profile));
  res.json({ success: true, messageTe: `స్వాగతం ${profile.name}! మీ ప్రొఫైల్ సేవ్ అయింది.`, profile });
});

app.get('/api/farmer/:phone', adminOnly, (req, res) => {
  const cleanPhone = String(req.params.phone).replace(/\D/g,'').slice(-10);
  const row=db.prepare('SELECT payload FROM profiles WHERE phone=?').get(cleanPhone);
  const profile=row && JSON.parse(row.payload);
  if (!profile) return res.status(404).json({ error: 'ప్రొఫైల్ దొరకలేదు. మళ్ళీ నమోదు చేయండి.' });
  res.json({ success: true, profile });
});

app.listen(PORT, () => {
  console.log(`Telugu farmer API listening on port ${PORT}`);
});

